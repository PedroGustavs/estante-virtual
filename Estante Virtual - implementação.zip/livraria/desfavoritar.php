
<?php


    $id = $_GET['id'];
    if($id > 0){
        session_start();
        include_once('conexao.php');
        $cod = $_SESSION['idusuario'];

        if($_SESSION['tipo_acesso'] != "usuario"){
            echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=livro.php?id=$id'>";
        }

        $query = "DELETE 
        FROM favoritado 
        WHERE codigo_usuario_codigo = $cod
        AND codigo_titulo_codigo = $id";
        $dados = mysqli_query($conn, $query);

        if($dados){
            echo "<script type='text/javascript'>alert('Livro Desfavoritado com Sucesso!');</script>";
            echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=livro.php?id=$id'>";
        }
        else{
            echo "<script>OpcaoMensagem(5)</script>";
            echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=livro.php?id=$id'>";
        }
        
    }
    else{
        echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=livro.php?id=$id'>";
    }
?>
<script src="js/funcoes.js"></script>