<?php
  session_start();
  include_once('conexao.php');
  include_once('sessao.php');//verifica se tem sessão e se está tudo ok!
  $exibirTipodeAcesso = $_SESSION['tipo_acesso'];//recebe o tipo de acesso
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="css/button.css">
        <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>
        <div class="container">
            <?php include_once('menu_user.php')?>

            <main>

                <div class="link">
                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="gerenciar_venda.php">Vendas</a>
                        </span>
                    </span>
                </div>

                <div class="recent-users">
                    <h2 class="crud">
                    <?php
                            if($exibirTipodeAcesso == "usuario") {
                                echo "Minhas Compras" ;
                            }
                            else {
                                echo "Gerenciar Vendas";
                            }
                        ?>
                    </h2>

                    <?php 
                        if ($exibirTipodeAcesso == "administrador") {
                    ?>

                    <table>
                        <thead>
                            <tr>
                                <th>Codigo</th>
                                <th>Titulo</th>
                                <th>Nome Livro</th>
                                <th>Usuário</th>
                                <th>Data</th>
                                <th>Preço</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                                $query = "SELECT * 
                                FROM venda, itemvenda, titulo, usuario
                                WHERE itemvenda.codigo_titulo_codigo = titulo.codigo_titulo
                                AND itemvenda.codigo_venda_codigo = venda.codigo_venda
                                AND venda.codigo_usuario_codigo = usuario.codigo_usuario
                                ORDER BY codigo_venda";
                                $row = mysqli_query($conn, $query);
                                while($dados = mysqli_fetch_assoc($row)){
                            ?>

                            <tr>
                                <td><?php echo $dados['codigo_venda']; ?></td>
                                <td><img
                                    src="imageTitle/<?php echo $dados['foto'];?>"
                                    alt="Imagem"
                                    width="80px"
                                    heigth="90px">
                                </td>
                                <td><?php echo $dados['titulo_nome'];?></td>
                                <td><?php echo $dados['usuario_nome'];?></td>
                                <td><?php echo $dados['data'];?></td>
                                <td><?php echo $dados['preco'];?></td>
                                <td><?php echo $dados['situacao'];?></td>

                                <td>
                                    <div class="td">
                                        <?php 
                                        echo"<a href='editar_venda.php?id=".$dados['codigo_venda']."' title='Alterar'><i class='fa fa-edit fa-2x'></i></a>";
                                        $id = $dados['codigo_venda'];
                                        echo"<a href='#' onclick='ConfirmarExclusaoVenda($id)' title='Excluir'><i class='fa fa-trash fa-2x'></i></a>";
                                    ?>
                                    </div>

                                </td>
                            </tr>

                            <?php
                                }
                            ?>
                        </tbody>

                    </table>
                    <div class="btn-box">
                        <input
                            type="button"
                            name="Cadastrar"
                            class="btn btn-primary pull-center"
                            value="Cadastrar Venda"
                            id="btn"
                            onclick="window.location.href='cadastrar_venda.php'">

                    </div>

                <?php
                }  else {
                ?>

                    <table>
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Livro</th>
                                <th>Situação Livro</th>
                                <th>Data Compra</th>
                                <th>Valor</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                                $cod = $_SESSION['idusuario'];
                                $query = "SELECT * 
                                FROM venda, itemvenda, titulo, usuario
                                WHERE itemvenda.codigo_titulo_codigo = titulo.codigo_titulo
                                AND usuario.codigo_usuario = $cod
                                AND itemvenda.codigo_venda_codigo = venda.codigo_venda
                                AND venda.codigo_usuario_codigo = usuario.codigo_usuario
                                ORDER BY venda.codigo_venda";
                                $row = mysqli_query($conn, $query);
                                while($dados = mysqli_fetch_assoc($row)){
                            ?>

                            <tr>
                                <td><?php echo $dados['titulo_nome']; ?></td>
                                <td><img
                                    src="imageTitle/<?php echo $dados['foto'];?>"
                                    alt="Imagem"
                                    width="80px"
                                    heigth="90px">
                                </td>
                                <td><?php echo $dados['status'];?></td>
                                <td><?php echo $dados['data'];?></td>
                                <td><?php echo $dados['preco'];?></td>
                                <td><?php echo $dados['situacao'];?></td>
                                <td>
                                    <div class="td">
                                        <?php 
                                        $titulo = $dados['codigo_titulo'];
                                        $op = 1;
                                            echo"<a href='carrinho_compra.php?id=".$dados['codigo_titulo']."'><i class='fas fa-shopping-cart fa-2x'></i></a>";
                                            echo "<a href='livro.php?id=".$dados['codigo_titulo']."'><i class='fa-solid fa-eye fa-2x'></i></a>";
                                        ?>
                                    </div>
                                </td>

                            </tr>

                            <?php
                                }
                            ?>
                        </tbody>

                    </table>

                    <?php
                    }
                ?>

                </div>
            </main>

        <?php
            if($exibirTipodeAcesso == "administrador"){
                include_once('right_user.php');
            }  
            
            else{
                ?>

            <div class="user-photo">
                <img
                    src="imageTitle/<?php echo $_SESSION['foto'];?>"
                    alt="Imagem"
                    width="80px"
                    heigth="90px">
                <h2><?php echo $_SESSION['nome']?></h2>
            </div>
            <?php
            }
            ?>
        </div>
    </body>
    <script src="js/funcoes.js"></script>

</html>

</body>

</html>