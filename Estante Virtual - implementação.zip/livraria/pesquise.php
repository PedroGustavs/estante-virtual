<?php
include_once('conexao.php');
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Estante Virtual</title>

        <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="css/header.css">
        <link rel="stylesheet" href="css/btn.css">
        <link rel="stylesheet" href="css/login.css">
        <link rel="stylesheet" href="css/section.css">

    </head>

    <body>
        <?php
            include_once('filtro_pesquisa.php');
            include_once('login.php');        
        ?>

        <section class="featured1" id="featured1">

            <h1 class="heading">
                <span>Resultados da Pesquisa</span>
            </h1>

        <?php
            if(isset($_GET['button-search'])){
                if(empty($_GET['search-box'])){
                    echo "nenhum resultado encontrado";
                }
                else{
                    $pesquisa = $_GET['search-box'];

                    if(empty($_GET['select-search'])){
                        echo "Nenhum resultado encontrado";
                    }

                    else{
                        $tipo = $_GET['select-search'];     
                        
                        if($tipo == "nome"){

                            $query = "SELECT *
                            FROM titulo
                            WHERE titulo_nome LIKE '%$pesquisa%'
                            ORDER BY valor ASC";         
                            $result = mysqli_query($conn, $query);
                            $num = mysqli_num_rows($result);

                            echo "<div class='alinhamento'><h1>Nome do Livro Pesquisado : $pesquisa </h1>";
                            echo "<h1>Resultados da Pesquisa : $num </h1></div>";

                            if(mysqli_num_rows($result) > 0){

                                echo "<div class='swiper featured-slider'>
                                        <div class='swiper-wrapper'>";
                            


                                while($dados = mysqli_fetch_assoc($result)){
                                    $titulo = $dados['codigo_titulo'];   
                                    $foto = $dados['foto'];  
                                    $nome = $dados['titulo_nome'];
                                    $valor = $dados['valor'];
                                    $valorFinal = number_format($valor, 2, ',', '.'); 

                                            echo "
                                                <div class='swiper-slide box'>
                                                    <div class='icons'>                           
                                                                                     
                                                        <a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                                            <i class='fa-solid fa-heart'></i>  
                                                        </a>

                                                        <a href='livro.php?id=$titulo' class='fas fa-eye'></a>
                                        
                                                    </div>
                                
                                                    <div class='image'>
                                                        <img src='imageTitle/$foto' alt='Imagem'>
                                                    </div>
                                
                                                    <div class='content'>
                                                        <h3>$nome</h3>
                                                        <div class='price'>
                                                            <h1>R$$valorFinal</h1>
                                                        </div>                            
                                                    </div>
                                                </div>";
                                                

                                }

                                echo "</div>
                                    <div class='swiper-button-next'></div>
                                <div class='swiper-button-prev'></div>
                                 </div>                                 
                                    ";

                         }
                         else{
                            echo "Nenhum resultado encontrado";
                         }

                        }

                        else if($tipo == "categoria"){

                            $query = "SELECT *
                            FROM categoria, titulo
                            WHERE categoria_nome LIKE '%$pesquisa%'
                            AND codigo_categoria = categoria_codigo
                            ORDER BY valor ASC";     
                            $result = mysqli_query($conn, $query);
                            $num = mysqli_num_rows($result);

                            echo "<h1>Nome da Categoria Pesquisada : $pesquisa </h1>";
                            echo "<h1>Resultados da Pesquisa : $num </h1>";

                            if(mysqli_num_rows($result) > 0){

                                echo "<div class='swiper featured-slider'>
                                        <div class='swiper-wrapper'>";
                            


                                while($dados = mysqli_fetch_assoc($result)){
                                    $titulo = $dados['codigo_titulo'];   
                                    $foto = $dados['foto'];  
                                    $nome = $dados['titulo_nome'];
                                    $valor = $dados['valor'];
                                    $valorFinal = number_format($valor, 2, ',', '.'); 

                                            echo "
                                                <div class='swiper-slide box'>
                                                    <div class='icons'>                           
                                                    
                                                    
                                                        <a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                                            <i class='fa-solid fa-heart'></i>  
                                                        </a>

                                                        <a href='livro.php?id=$titulo' class='fas fa-eye'></a>
                                        
                                                    </div>
                                
                                                    <div class='image'>
                                                        <img src='imageTitle/$foto' alt='Imagem'>
                                                    </div>
                                
                                                    <div class='content'>
                                                        <h3>$nome</h3>
                                                        <div class='price'>
                                                            <h1>R$$valorFinal</h1>
                                                        </div>                            
                                                    </div>
                                                </div>";
                                                

                                }

                                echo "</div>
                                    <div class='swiper-button-next'></div>
                                <div class='swiper-button-prev'></div>
                                 </div>                                 
                                    ";

                         }
                         else{
                            echo "Nenhum resultado encontrado";
                         }
                        }

                        else if($tipo == "editora"){

                            $query = "SELECT *
                            FROM editora, titulo
                            WHERE editora_nome LIKE '%$pesquisa%'
                            AND codigo_editora = editora_codigo
                            ORDER BY valor ASC";     
                            $result = mysqli_query($conn, $query);
                            $num = mysqli_num_rows($result);

                            echo "<h1>Nome da Editora Pesquisada : $pesquisa </h1>";
                            echo "<h1>Resultados da Pesquisa : $num </h1>";

                            if(mysqli_num_rows($result) > 0){

                                echo "<div class='swiper featured-slider'>
                                        <div class='swiper-wrapper'>";
                            


                                while($dados = mysqli_fetch_assoc($result)){
                                    $titulo = $dados['codigo_titulo'];   
                                    $foto = $dados['foto'];  
                                    $nome = $dados['titulo_nome'];
                                    $valor = $dados['valor'];
                                    $valorFinal = number_format($valor, 2, ',', '.'); 

                                            echo "
                                                <div class='swiper-slide box'>
                                                    <div class='icons'>                           
                                                       
                                                    
                                                        <a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                                            <i class='fa-solid fa-heart'></i>  
                                                        </a>

                                                        <a href='livro.php?id=$titulo' class='fas fa-eye'></a>
                                        
                                                    </div>
                                
                                                    <div class='image'>
                                                        <img src='imageTitle/$foto' alt='Imagem'>
                                                    </div>
                                
                                                    <div class='content'>
                                                        <h3>$nome</h3>
                                                        <div class='price'>
                                                            <h1>R$$valorFinal</h1>
                                                        </div>                            
                                                    </div>
                                                </div>";
                                                

                                }

                                echo "</div>
                                    <div class='swiper-button-next'></div>
                                <div class='swiper-button-prev'></div>
                                 </div>                                 
                                    ";

                         }
                         else{
                            echo "Nenhum resultado encontrado";
                         }


                        }

                        else if($tipo == "autor"){

                            $query = "SELECT *
                            FROM autor, titulo, autor_titulo
                            WHERE autor_nome LIKE '%$pesquisa%'
                            AND codigo_autor_codigo = codigo_autor
                            AND codigo_titulo_codigo = codigo_titulo
                            ORDER BY valor ASC";     
                            $result = mysqli_query($conn, $query);
                            $num = mysqli_num_rows($result);

                            echo "<h1>Nome do(a) autor(a) Pesquisado(a) : $pesquisa </h1>";
                            echo "<h1>Resultados da Pesquisa : $num </h1>";

                            if(mysqli_num_rows($result) > 0){

                                echo "<div class='swiper featured-slider'>
                                        <div class='swiper-wrapper'>";
                            


                                while($dados = mysqli_fetch_assoc($result)){
                                    $titulo = $dados['codigo_titulo'];   
                                    $foto = $dados['foto'];  
                                    $nome = $dados['titulo_nome'];
                                    $valor = $dados['valor'];
                                    $valorFinal = number_format($valor, 2, ',', '.'); 

                                            echo "
                                                <div class='swiper-slide box'>
                                                    <div class='icons'>                           
                                                       
                                                    
                                                        <a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                                            <i class='fa-solid fa-heart'></i>  
                                                        </a>

                                                        <a href='livro.php?id=$titulo' class='fas fa-eye'></a>
                                        
                                                    </div>
                                
                                                    <div class='image'>
                                                        <img src='imageTitle/$foto' alt='Imagem'>
                                                    </div>
                                
                                                    <div class='content'>
                                                        <h3>$nome</h3>
                                                        <div class='price'>
                                                            <h1>R$$valorFinal</h1>
                                                        </div>                            
                                                    </div>
                                                </div>";
                                                

                                }

                                echo "</div>
                                    <div class='swiper-button-next'></div>
                                <div class='swiper-button-prev'></div>
                                 </div>                                 
                                    ";

                         }
                         else{
                            echo "Nenhum resultado encontrado";
                         }

                        }

                        else if($tipo == "assunto"){

                            $query = "SELECT *
                            FROM titulo
                            WHERE descricao LIKE '%$pesquisa%'
                            ORDER BY valor ASC";     
                            $result = mysqli_query($conn, $query);

                            $num = mysqli_num_rows($result);

                            echo "<h1>Assunto do Livro Pesquisado : $pesquisa </h1>";
                            echo "<h1>Resultados da Pesquisa : $num </h1>";

                            if(mysqli_num_rows($result) > 0){

                                echo "<div class='swiper featured-slider'>
                                        <div class='swiper-wrapper'>";
                            


                                while($dados = mysqli_fetch_assoc($result)){
                                    $titulo = $dados['codigo_titulo'];   
                                    $foto = $dados['foto'];  
                                    $nome = $dados['titulo_nome'];
                                    $valor = $dados['valor'];
                                    $valorFinal = number_format($valor, 2, ',', '.'); 

                                            echo "
                                                <div class='swiper-slide box'>
                                                    <div class='icons'>                           
                                                       
                                                    
                                                        <a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                                            <i class='fa-solid fa-heart'></i>  
                                                        </a>

                                                        <a href='livro.php?id=$titulo' class='fas fa-eye'></a>
                                        
                                                    </div>
                                
                                                    <div class='image'>
                                                        <img src='imageTitle/$foto' alt='Imagem'>
                                                    </div>
                                
                                                    <div class='content'>
                                                        <h3>$nome</h3>
                                                        <div class='price'>
                                                            <h1>R$$valorFinal</h1>
                                                        </div>                            
                                                    </div>
                                                </div>";
                                                

                                }

                                echo "</div>
                                    <div class='swiper-button-next'></div>
                                <div class='swiper-button-prev'></div>
                                 </div>                                 
                                    ";

                         }
                         else{
                            echo "Nenhum resultado encontrado";
                         }

                        }

                        else if($tipo == "preco"){
                       
                            $query = "SELECT *
                            FROM titulo
                            WHERE valor BETWEEN 0 AND $pesquisa
                            ORDER BY valor ASC";     
                            $result = mysqli_query($conn, $query);

                            $num = mysqli_num_rows($result);

                            echo "<h1>Preço Maximo Pesquisado : $pesquisa </h1>";
                            echo "<h1>Resultados da Pesquisa : $num </h1>";

                            if(mysqli_num_rows($result) > 0){

                                echo "<div class='swiper featured-slider'>
                                        <div class='swiper-wrapper'>";
                            


                                while($dados = mysqli_fetch_assoc($result)){
                                    $titulo = $dados['codigo_titulo'];   
                                    $foto = $dados['foto'];  
                                    $nome = $dados['titulo_nome'];
                                    $valor = $dados['valor'];
                                    $valorFinal = number_format($valor, 2, ',', '.'); 

                                            echo "
                                                <div class='swiper-slide box'>
                                                    <div class='icons'>                           
                                                       
                                                    
                                                        <a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                                            <i class='fa-solid fa-heart'></i>  
                                                        </a>

                                                        <a href='livro.php?id=$titulo' class='fas fa-eye'></a>
                                        
                                                    </div>
                                
                                                    <div class='image'>
                                                        <img src='imageTitle/$foto' alt='Imagem'>
                                                    </div>
                                
                                                    <div class='content'>
                                                        <h3>$nome</h3>
                                                        <div class='price'>
                                                            <h1>R$$valorFinal</h1>
                                                        </div>                            
                                                    </div>
                                                </div>";
                                                

                                }

                                echo "</div>
                                    <div class='swiper-button-next'></div>
                                <div class='swiper-button-prev'></div>
                                 </div>                                 
                                    ";

                         }
                         else{
                            echo "Nenhum resultado encontrado";
                         }

                        
                        
                        }

                        else if($tipo == "preco1"){
                       
                            $query = "SELECT *
                            FROM titulo
                            WHERE valor BETWEEN $pesquisa AND  > $pesquisa
                            ORDER BY valor ASC";     
                            $result = mysqli_query($conn, $query);
                            $num = mysqli_num_rows($result);

                            echo "<h1>Preço Minimo Pesquisado : $pesquisa </h1>";
                            echo "<h1>Resultados da Pesquisa : $num </h1>";

                            if(mysqli_num_rows($result) > 0){

                                echo "<div class='swiper featured-slider'>
                                        <div class='swiper-wrapper'>";
                            


                                while($dados = mysqli_fetch_assoc($result)){
                                    $titulo = $dados['codigo_titulo'];   
                                    $foto = $dados['foto'];  
                                    $nome = $dados['titulo_nome'];
                                    $valor = $dados['valor'];
                                    $valorFinal = number_format($valor, 2, ',', '.'); 

                                            echo "
                                                <div class='swiper-slide box'>
                                                    <div class='icons'>                           
                                                        
                                                    
                                                        <a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                                            <i class='fa-solid fa-heart'></i>  
                                                        </a>

                                                        <a href='livro.php?id=$titulo' class='fas fa-eye'></a>
                                        
                                                    </div>
                                
                                                    <div class='image'>
                                                        <img src='imageTitle/$foto' alt='Imagem'>
                                                    </div>
                                
                                                    <div class='content'>
                                                        <h3>$nome</h3>
                                                        <div class='price'>
                                                            <h1>R$$valorFinal</h1>
                                                        </div>                            
                                                    </div>
                                                </div>";
                                                

                                }

                                echo "</div>
                                    <div class='swiper-button-next'></div>
                                <div class='swiper-button-prev'></div>
                                 </div>                                 
                                    ";

                         }
                         else{
                            echo "Nenhum resultado encontrado";
                         }

                        }
                        
                    }
                }
            }
        ?>
        </section>

        <section class="featured" id="featured">

            <h1 class="heading">
                <span>Novidades que voce precisa conheçer</span>
            </h1>

            <div class="swiper featured-slider">

                <div class="swiper-wrapper">
                    <?php

                            $query = "SELECT t.*
                            FROM titulo t, categoria c, autor a, autor_titulo a_t, editora e
                            WHERE t.editora_codigo = e.codigo_editora
                            AND t.categoria_codigo = c.codigo_categoria
                            AND a.codigo_autor = a_t.codigo_autor_codigo
                            AND t.codigo_titulo = a_t.codigo_titulo_codigo
                            ORDER BY t.codigo_titulo";
                            $row = mysqli_query($conn, $query);
                            $num = mysqli_num_rows($row);

                          

                            while($dados = mysqli_fetch_assoc($row)){
                        ?>
                    <div class="swiper-slide box">
                        <div class="icons">
                            <?php        
                                $titulo = $dados['codigo_titulo'];
                                echo"<a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                    <i class='fa-solid fa-heart'></i>  
                                </a>";
                                echo"<a href='livro.php?id=".$dados['codigo_titulo']."' class='fas fa-eye'></a>";
                            ?>
                        </div>

                        <div class="image">
                            <img src="imageTitle/<?php echo $dados['foto'];?>" alt="Imagem">
                        </div>

                        <div class="content">
                            <h3><?php echo $dados['titulo_nome'] ?></h3>
                            <div class="price">
                                <h1>R$<?php echo number_format($dados['valor'], 2, ',', '.')?></h1>
                            </div>
                        </div>
                    </div>
                    <?php
                            }
                        
                    ?>

                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </section>

        <section class="featured1" id="featured1">

            <h1 class="heading">
                <span>Os mais populares</span>
            </h1>

            <div class="swiper featured-slider">

                <div class="swiper-wrapper">

                    <?php
                            $query = "SELECT COUNT(*) AS qntd_vendido, codigo_titulo, titulo_nome, foto, preco, valor
                            FROM titulo, venda, itemvenda, usuario
                            WHERE codigo_titulo = codigo_titulo_codigo
                            AND codigo_venda = codigo_venda_codigo
                            AND codigo_usuario = codigo_usuario_codigo
                            GROUP BY codigo_venda 
                            ORDER BY qntd_vendido DESC LIMIT 9";         
                            $result = mysqli_query($conn, $query);
                            $num = mysqli_num_rows($result);
                            echo $num;

                            while($dados = mysqli_fetch_assoc($result)){

                        ?>
                    <div class="swiper-slide box">
                        <div class="icons">
                            <?php
                                
                                $titulo = $dados['codigo_titulo'];
                                echo"<a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                    <i class='fa-solid fa-heart'></i>  
                                </a>";
                                echo"<a href='livro.php?id=".$dados['codigo_titulo']."' class='fas fa-eye'></a>";
                            ?>
                        </div>

                        <div class="image">
                            <img src="imageTitle/<?php echo $dados['foto'];?>" alt="Imagem">
                        </div>

                        <div class="content">
                            <h3><?php echo $dados['titulo_nome'] ?></h3>
                            <div class="price">
                                <h1>R$<?php echo number_format($dados['valor'], 2, ',', '.')?></h1>
                            </div>
                        </div>
                    </div>

                    <?php
            }
           
            ?>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>

        </section>

        <?php
            include_once('rodape.php');
        ?>

        <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

        <script src="js/script.js"></script>

    </body>

</html>