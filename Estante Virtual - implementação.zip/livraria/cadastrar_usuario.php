<?php
  include_once('conexao.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/cadastrar.css">
    <link rel="stylesheet" href="css/button.css">
    <title>Cadastro Leitor </title> 
</head>
<body>
    <div class="container">
        <header>Cadastro Leitor</header>

        <form action="#" method="post" enctype="multipart/form-data">
            <div class="form first">
                <div class="details personal">
                    <span class="title">Dados Pessoais</span>

                    <div class="fields">
                        <div class="input-field">
                            <label for="nome">Nome</label>
                            <input type="text" name="nome" id="nome" placeholder="Informe o nome do leitor">
                        </div>

                        <div class="input-field">
                                    <label for="foto">Imagem</label>

                                    <input type="file" required="required" name="foto" id="foto" onchange="previewImagem()">
                                    
                                </div>

                        <div class="input-field">
                            <label for="email">Email</label>
                            <input type="email" name="email" id="email" placeholder="Informe o seu email">
                        </div>

                        <div class="input-field">
                            <label for="telefone">telefone</label>
                            <input type="tel" name="telefone" id="telefone" placeholder="Informe o seu telefone">
                        </div>

                        <div class="input-field">
                            <label for="senha">Senha</label>
                            <input type="password" name="senha" id="senha" placeholder="Informe a senha">
                        </div>

                        <div class="input-field">
                            <label for="senha1">Confirmação da Senha</label>
                            <input type="password" name="senha1" id="senha1" placeholder="Informe a senha novamente">
                        </div>

                    </div>
                </div>

                <div class="details ID">
                    <span class="title">Endereço</span>

                    <div class="fields">

                        <div class="input-field">
                            <label for="rua">Rua</label>
                            <input type="text" name="rua" id="rua" placeholder="Informe a rua">
                        </div>

                        <div class="input-field">
                            <label for="numero">Número</label>
                            <input type="number" name="numero" id="numero" placeholder="Informe o numero da rua">
                        </div>

                        <div class="input-field">
                            <label for="bairro">Bairro</label>
                            <input type="text" name="bairro" id="bairro" placeholder="Informe o bairro">
                        </div>

                        <div class="input-field">
                            <label for="cep">CEP</label>
                            <input type="text" name="cep" id="cep" placeholder="Informe o Cep">
                        </div>

                        <div class="input-field">
                            <label for="cidade">Cidade</label>
                            <input type="text" name="cidade" id="cidade" placeholder="Informe a Cidade">
                        </div>

                        <div class="input-field">
                            <label for="estado">Estado</label>
                            <input type="text" name="estado" id="estado" placeholder="Informe o Estado">
                        </div>                   
                    </div>

                    <div class="login-button">
                            <input type="button" name="cancelar" class="btn btn-primary btn-block mt-3" id="btn"
                                value="Cancelar" onclick="window.location.href='index.php'">
                            <input type="submit" name="cadastrar" class="btn btn-primary btn-block mt-3" id="btn"
                                value="Cadastrar">
                        </div>
                   
                </div> 
            </div>
        </form>
    </div>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
        <script>
            $("#telefone").mask("(99) 9999-9999");
            $("#cep").mask("99999-999");
        </script>

<script src="js/estado.js"></script>

            
<script src="https://code.jquery.com/jquery-3.4.1.min.js" 
            integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo=" 
                crossorigin="anonymous"></script>
        <!-- Adicionando Javascript -->
        <script>
            $(document).ready(function() {
                function limpa_formulário_cep() {
                    $("#cidade").val("");
                    $("#estado").val("");
                }

                $("#cep").blur(function() {
                    var cep = $(this).val().replace(/\D/g, '');
                    if (cep != "") {
                        var validacep = /^[0-9]{8}$/;
                        if(validacep.test(cep)) {

                            $("#cidade").val("...");
                            $("#estado").val("...");

                            $.getJSON("https://viacep.com.br/ws/"+ cep +"/json/?callback=?", function(dados) {

                                if (!("erro" in dados)) {

                                    $("#cidade").val(dados.localidade);
                                    $("#estado").val(dados.uf);
                                } //end if.
                                else {
                                    //CEP pesquisado não foi encontrado.
                                    limpa_formulário_cep();
                                    alert("CEP não encontrado.");
                                }
                            });
                        } //end if.
                        else {
                            //cep é inválido.
                            limpa_formulário_cep();
                            alert("Formato de CEP inválido.");
                        }
                    } //end if.
                    else {
                        //cep sem valor, limpa formulário.
                        limpa_formulário_cep();
                    }
                });
            });
        </script>
    <script src="funcoes.js"></script>
</body>
</html>

<?php
    //se ele clicou no botão salvar
        if (isset($_POST['cadastrar'])) {
            if (!empty($_POST) && (empty($_POST['nome']) || empty($_POST['email']) || empty($_POST['telefone']) || empty($_POST['cidade'])
            || empty($_POST['estado']) || empty($_POST['rua']) || empty($_POST['numero']) ||
            empty($_POST['senha']) || empty($_POST['senha1']) || empty($_POST['cep']) || empty($_POST['bairro']))) {
            echo "<script type='text/javascript'>alert('Preencha todos os campos!');</script>";
            echo '<meta HTTP-EQUIV="refresh" CONTENT="0; URL=cadastrar_usuario.php">';
        }
        else{
            if (isset($_FILES['foto']['name']) && $_FILES['foto']['error'] == 0) {
                $arquivo_tmp = $_FILES['foto']['tmp_name'];
                $nome = $_FILES['foto']['name'];//images.png
                $extensao = strrchr($nome, '.');//png
                $extensao = strtolower($extensao);
                if (strstr('.svg;.pdf;.png;.jpg;.jpeg;.gif', $extensao)) {
                    $novoNome = md5(microtime()) . '.' . $extensao;
                    $destino = 'imageTitle/' . $novoNome;
                    if (@move_uploaded_file($arquivo_tmp, $destino)) {
                        echo "Arquivo salvo com sucesso";
                    } else {
                        echo "Erro ao salvar o arquivo";
                    }           
                } else {
                    echo "Formato de arquivo invalido!";
                }            

                $email = $_POST['email'];
                
                $query = "SELECT email 
                FROM usuario 
                WHERE usuario.email = '$email'";
                $row = mysqli_query($conn, $query);
                $num = mysqli_num_rows($row);

                if ($num > 0) {
                    echo "<script type='text/javascript'>alert('Email já cadastrado!');</script>";
                    echo '<meta HTTP-EQUIV="Refresh" CONTENT="0 URL=cadastrar_usuario.php">';
                }

                else{
                    $name = $_POST['nome'];
                    $telefone = $_POST['telefone'];
                    $estado = $_POST['estado'];
                    $cidade = $_POST['cidade'];
                    $cep = $_POST['cep'];
                    $bairro = $_POST['bairro'];
                    $numero = $_POST['numero'];
                    $rua = $_POST['rua'];
                    $tipo = "usuario";
                    $img_user = $novoNome;

                    $senha = $_POST['senha'];
                    $senha1 = $_POST['senha1'];
                    if($senha != $senha1){
                        echo "<script type='text/javascript'>alert('As senhas devem ser iguais!');</script>";
                        echo '<meta HTTP-EQUIV="Refresh" CONTENT="0 URL=cadastrar_usuario.php">';

                    } else{
                        $senhaCript = password_hash($senha, PASSWORD_DEFAULT); 
                                
                        $comandoParaInsercao = "INSERT INTO `usuario`(`usuario_nome`, `telefone`, `tipo`,`email`, `senha`, 
                        `cidade`, `estado`, `rua`, `numero`, `cep`, `bairro`, `foto_user`)
                        VALUES ('$name','$telefone', '$tipo', '$email', '$senhaCript', '$cidade', '$estado'
                        , '$rua', '$numero', '$cep', '$bairro', '$img_user')";

                        $resultado = mysqli_query($conn, $comandoParaInsercao); //executa o codigo acima no banco

                        if($resultado){                   
                            echo "<script type='text/javascript'>OpcaoMensagens(1);</script>";
                            echo '<meta HTTP-EQUIV="Refresh" CONTENT="0 URL=index.php">';
                        }else{
                            echo "<script type='text/javascript'>alert('Erro ao inserir!');</script>";
                        }     
                    } 
                }
            }          
        }
    }
        
    ?>