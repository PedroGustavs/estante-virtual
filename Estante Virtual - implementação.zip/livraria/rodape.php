<section class="footer">
    <div class="box-container">

        <div class="box">
            <h3> Links Rapidos</h3>
            <a href="#"> <i class="fas fa-arrow-right"></i> home </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> Livros </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> Novidades </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> Populares </a>
            <a href="#"> <i class="fas fa-arrow-right"></i> Opiniões </a>
        </div>

        <div class="box">
            <h3>Contato</h3>
            <a href="#"> <i class="fas fa-phone"></i> +123-456-7890 </a>
            <a href="#"> <i class="fas fa-phone"></i> +111-222-3333 </a>
            <a href="#"> <i class="fas fa-envelope"></i> pedro.gustavo@gmail.com </a>
            <img src="image/worldmap.png" class="map" alt="">
        </div>

    </div>

    <div class="share">
        <a href="#" class="fab fa-facebook-f"></a>
        <a href="#" class="fab fa-twitter"></a>
        <a href="#" class="fab fa-instagram"></a>
        <a href="#" class="fab fa-linkedin"></a>
        <a href="#" class="fab fa-pinterest"></a>
    </div>

</section>