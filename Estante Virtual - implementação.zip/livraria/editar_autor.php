<?php
  session_start();
  include_once('sessao.php');//verifica se tem sessão e se está tudo ok!
  //chama a conecao com banco de dados
  include_once('conexao.php');

$exibirTipodeAcesso = $_SESSION['tipo_acesso'];

if($exibirTipodeAcesso != "administrador"){
    header("location:dashboard.php");
    echo "<script type='text/javascript'>alert('Apenas o Administrador possui acesso a essa área!');</script>";
}

  $id = 0;
  $linhaunica=null;
  if(isset($_GET['id'])){
    $id = $_GET['id'];
    $query = "SELECT * FROM autor WHERE codigo_autor = $id";
    $dados = mysqli_query($conn, $query);

    if(!$dados){
        
        //echo '<script type="text/javascript" src="../js/funcoes.js">console.log("asd")</script>';
        echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=listar_autor.php'>";
        exit;
    }

    $linhaunica = mysqli_fetch_assoc($dados);
  } else{
        header("location:dashboard.php");
  }

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Editar Autor</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="css/button.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>
        <div class="container">
            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">
                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="listar_autor.php">Listagem Autor</a>
                        </span>
                        <span>
                            >
                            <a href="editar_autor.php">Editar Autor</a>
                        </span>
                    </span>
                </div>

                <div class="recent-users">

                    <div class="form form1">
                        <h2 class="crud">Alteração Autor</h2>
                        <form action="#" method="post">
                            <div class="input-group">
                                <div class="input-box">
                                    <label for="nome" class="form-label">Nome</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        name="nome"
                                        id="nome"
                                        placeholder="Informe o nome do autor"
                                        value="<?php echo $linhaunica['autor_nome']?>">
                                </div>
                            </div>

                            <div class="login-button">
                                <input
                                    type="button"
                                    name="cancelar"
                                    class="btn btn-primary btn-block mt-3"
                                    id="btn"
                                    value="Cancelar"
                                    onclick="window.location.href='listar_autor.php'">
                                <input
                                    type="submit"
                                    name="alterar"
                                    class="btn btn-primary btn-block mt-3"
                                    id="btn"
                                    value="Alterar">
                            </div>

                        </form>
                    </div>

                </div>
            </main>

            <?php
            include_once('right_user.php');
            ?>
        </div>
    </body>
    <script src="js/funcoes.js"></script>
</html>

<?php
    if(isset($_POST['alterar'])){
        if(!empty($_POST) && (empty($_POST['nome']))){
            echo "<script type='text/javascript'>alert('Preencha todos os campos!');</script>";
            echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=editar_autor.php?id=$id'>";      
        }
        else{
            $name = $_POST['nome'];           
            $result = "UPDATE autor SET autor_nome = '$name' WHERE codigo_autor = $id";        
            $row = mysqli_query($conn, $result);

            if ($row) {
                echo "<script type='text/javascript'>OpcaoMensagens(2);</script>";
                echo '<meta HTTP-EQUIV="Refresh" CONTENT="0; URL=listar_autor.php">';
            } else {    
                echo "<script type='text/javascript'>OpcaoMensagens(5);</script>";
                echo '<meta HTTP-EQUIV="Refresh" CONTENT="0; URL=listar_autor.php">';
            }
        }
    }
?>