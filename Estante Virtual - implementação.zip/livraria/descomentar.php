
<?php

$id = $_GET['id'];
$coment = $_GET['coment'];
if($id > 0 && isset($coment)){

    session_start();
    include_once('conexao.php');
    $cod = $_SESSION['idusuario'];

    if($_SESSION['tipo_acesso'] != "usuario"){
        echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=index.php'>";
    }

    $query = "DELETE 
    FROM comentario 
    WHERE codigo_usuario_codigo = $cod
    AND codigo_titulo_codigo = $id
    AND codigo_comentario = $coment";
    $dados = mysqli_query($conn, $query);


    if($dados){
        echo "<script type='text/javascript'>alert('Comentário excluido com Sucesso!');</script>";
        echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=livro.php?id=$id'>";
    }

    else{
        echo "<script>OpcaoMensagem(5)</script>";
        echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=livro.php?id=$id'>";
    }
}
else{
    echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=index.php'>";
}
?>
<script src="js/funcoes.js"></script>