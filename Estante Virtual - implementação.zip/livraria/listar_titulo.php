<?php
session_start();
include_once('sessao.php');
include_once('conexao.php');
$exibirTipodeAcesso = $_SESSION['tipo_acesso'];//recebe o tipo de acesso

if($exibirTipodeAcesso != "administrador"){
    header("location:dashboard.php");
    echo "<script type='text/javascript'>alert('Apenas o Administrador possui acesso a essa área!');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Listagem do(s) Títulos</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="css/button.css">
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>
        <div class="container">
            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">
                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="listar_titulo.php">Listagem Título</a>
                        </span>
                    </span>
                </div>

                <div class="recent-users">

                    <table>
                        <h2 class="crud">Listagem de Título</h2>
                        <thead>
                            <tr>
                                <th>Codigo</th>
                                <th>Imagem</th>
                                <th>Nome</th>
                                <th>Status</th>
                                <th>Autor(es)</th>
                                <th>Categoria</th>
                                <th>Editora</th>
                                <th>Quantidade Página</th>
                                <th>Ação</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                                $query = "SELECT t.*, c.*, e.*
                                FROM titulo t, categoria c, editora e
                                WHERE t.editora_codigo = e.codigo_editora
                                AND t.categoria_codigo = c.codigo_categoria
                                ORDER BY t.codigo_titulo";
                                $row = mysqli_query($conn, $query);
                                while($dados = mysqli_fetch_assoc($row)){
                            ?>

                            <tr>
                                <td><?php echo $dados['codigo_titulo'];?></td>
                                <td>
                                    <img
                                        src="imageTitle/<?php echo $dados['foto'];?>"
                                        alt="Imagem"
                                        width="80px"
                                        heigth="90px">
                                </td>

                                <td><?php echo $dados['titulo_nome'];?></td>
                                <td><?php echo $dados['status'];?></td>
                                <td>
                                    <?php
                                        $query = "SELECT autor_nome from autor_titulo a_t, autor a where codigo_titulo_codigo = ".$dados['codigo_titulo']." and codigo_autor_codigo = a.codigo_autor";
                                        $result = mysqli_query($conn, $query);

                                        while($nomes = mysqli_fetch_assoc($result)){
                                            echo $nomes['autor_nome'].";";
                                        }
                                    ?>
                                </td>

                                <td><?php echo $dados['categoria_nome'];?></td>
                                <td><?php echo $dados['editora_nome'];?></td>
                                <td><?php echo $dados['qntdd_pag']; ?></td>
                                
                                <td>
                                    <div class="td">
                                        <?php 
                                            echo"<a href='editar_titulo.php?id=".$dados['codigo_titulo']."' title='Alterar'><i class='fa fa-edit fa-2x'></i></a>";
                                            $id = $dados['codigo_titulo'];
                                            echo"<a href='#' onclick='ConfirmarExclusaoTitulo($id)' title='Excluir'><i class='fa fa-trash fa-2x'></i></a>";
                                        ?>
                                    </div>
                                </td>
                            </tr>

                            <?php
                                }
                            ?>
                        </tbody>
                    </table>

                    <div class="btn-box">
                        <input
                            type="button"
                            name="Cadastrar"
                            class="btn btn-primary pull-center"
                            value="Cadastrar Título"
                            id="btn"
                            onclick="window.location.href='cadastrar_titulo.php'">
                    </div>
                </div>
            </main>

            <?php
            include_once('right_user.php');
            ?>
        </div>
    </body>
    <script src="js/funcoes.js"></script>
</html>