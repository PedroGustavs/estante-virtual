<?php
  session_start();
  include_once('sessao.php');//verifica se tem sessão e se está tudo ok!
  $exibirTipodeAcesso = $_SESSION['tipo_acesso'];//recebe o tipo de acesso
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Conta e Segurança</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>

        <div class="container">

            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">

                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="configuracao.php">Configuração</a>
                        </span>               
                    </span>
                </div>

                <div class="insights">

                    <div class="sales">
                        <a href="meu_perfil.php">
                            <span class="material-symbols-sharp">
                                visibility
                            </span>

                            <h3 class="h3">Meu Perfil</h3>
                        </a>

                    </div>

                    <?php
                if($exibirTipodeAcesso == "usuario"){
                   
                    $id = $_SESSION['idusuario'];

                    $query = "SELECT *
                    FROM usuario, venda, itemvenda, titulo
                    WHERE codigo_usuario_codigo  = codigo_usuario
                    AND codigo_usuario = $id
                    AND codigo_titulo_codigo = codigo_titulo
                    AND codigo_venda_codigo  = codigo_venda";
                    $dados = mysqli_query($conn, $query);
                    $num = mysqli_num_rows($dados);

                    $query = "SELECT *
                    FROM usuario, comentario, titulo
                    WHERE codigo_usuario_codigo  = codigo_usuario
                    AND codigo_usuario = $id
                    AND codigo_titulo_codigo = codigo_titulo
                    ";
                    $dados1 = mysqli_query($conn, $query);
                    $num1 = mysqli_num_rows($dados1);

                    $query = "SELECT *
                    FROM usuario, favoritado, titulo
                    WHERE codigo_usuario_codigo  = codigo_usuario
                    AND codigo_usuario = $id
                    AND codigo_titulo_codigo = codigo_titulo";
                    $dados2 = mysqli_query($conn, $query);
                    $num2 = mysqli_num_rows($dados2);

                   




                    echo "<div class='sale'>

                        <a href='#' onclick='excluir($id, $num, $num1, $num2)'>
                            <span class='material-symbols-sharp'>
                                delete
                            </span>

                            <h3 class='h3'>
                                Excluir Conta
                            </h3>
                        </a>
                    </div>";

 
                    include_once('conexao.php');
                    

                   

                    }   
            
            ?>
                </div>
            </main>

            <?php
            if($exibirTipodeAcesso == "administrador"){
                include_once('right_user.php');
            }  
            
            else{
                ?>

                <div class="user-photo">
                    <img
                                        src="imageTitle/<?php echo $_SESSION['foto'];?>"
                                        alt="Imagem"
                                        width="80px"
                                        heigth="90px">
                <h2><?php echo $_SESSION['nome']?></h2> 
            </div>
            <?php
            }
        ?>
        </div>
        <script src="js/funcoes.js"></script>

    </body>
</html>