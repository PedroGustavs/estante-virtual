<?php
session_start();
include_once('sessao.php');
include_once('conexao.php');
$exibirTipodeAcesso = $_SESSION['tipo_acesso'];

if($exibirTipodeAcesso != "administrador"){
    header("location:dashboard.php");
    echo "<script type='text/javascript'>alert('Apenas o Administrador possui acesso a essa área!');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Listagem da(s) Categoria(s)</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="css/button.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
        <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0" />
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>
        <div class="container">
            <?php include_once('menu_user.php')?>
            
            <main>
            <div class="link">
            <span>
                    <a href="dashboard.php">
                        Dashboard
                    </a>
                </span>
                
            </div>
                

                <div class="recent-users">
                <h2 class="crud">Listagem de solicitações </h2>
                
                <table>
                <thead>
                            <tr>
                                <th>Codigo</th>
                                <th>Nome</th>
                                <th>Excluir</th>
                            </tr>
                        </thead>

                
                        <tbody>
                            <?php
                                 $query = "SELECT *
                                 FROM usuario
                                 WHERE tipo = 'usuario'
                                 AND pedido = 'solicitado'
                                 ORDER BY codigo_usuario";
                                 $result = mysqli_query($conn, $query);

                                while($dados = mysqli_fetch_assoc($result)){
                            ?>
                    
                            <tr>
                                <td><?php echo $dados['codigo_usuario']; ?></td>  
                                <td><?php echo $dados['usuario_nome'];?></td>                           
                                <td>
                                    <div class="td">
                                        <?php 
        

                                            $id = $dados['codigo_usuario'];
                                        echo"<a href='#' onclick='ConfirmarExclusaoUsuario($id)' title='Excluir'>
                                        <i class='fa fa-trash fa-2x'></i>
                                        </a>";
                                        ?>
                                    </div>
                                </td>                                                                
                            </tr>

                            <?php
                                }
                            ?>
                        </tbody>

                    </table>
                </div>               
            </main>

            <?php
            include_once('right_user.php');
            ?>
        </div>
    </body>
    <script src="js/funcoes.js"></script>
</html>