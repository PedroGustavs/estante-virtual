<?php
  session_start();
  include_once('sessao.php');
  include_once('conexao.php');

 $exibirTipodeAcesso = $_SESSION['tipo_acesso'];
 
 if($exibirTipodeAcesso != "administrador"){
     header("location:dashboard.php");
     echo "<script type='text/javascript'>alert('Apenas o Administrador possui acesso a essa área!');</script>";
 }
 
 $id=$_GET['id'];
 $i = 0;
 if (isset($id)) {
     $query = "SELECT c.*, e.*, t.*, a.*, a_t.*
     FROM autor a, categoria c, editora e, titulo t, autor_titulo a_t
     WHERE a_t.codigo_autor_codigo = a.codigo_autor
     AND t.editora_codigo = e.codigo_editora 
     AND t.categoria_codigo = c.codigo_categoria 
     AND a_t.codigo_titulo_codigo = t.codigo_titulo
     AND t.codigo_titulo = $id 
     AND a_t.codigo_titulo_codigo = $id";
     $dados = mysqli_query($conn, $query);
     $linha = mysqli_fetch_assoc($dados);
 }
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Editar Titulo</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="css/button.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>
        <div class="container">
            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">
                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="listar_titulo.php">Listagem Título</a>
                        </span>
                        <span>
                            >
                            <a href="editar_titulo.php">Editar Título</a>
                        </span>
                    </span>
                </div>

                <div class="recent-users">
                    <h2 class="crud">Alteração Título</h2>
                    <div class="form form2">
                        <form
                            action="editar_titulo.php?id=<?php echo $_GET['id']; ?>"
                            method="post"
                            enctype="multipart/form-data">
                            <div class="input-group grid1">
                                <div class="input-box">
                                    <label for="name" class="form-label">Nome</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        name="name"
                                        id="name"
                                        placeholder="Informe o nome da editora"
                                        value="<?php echo $linha['titulo_nome']?>">
                                </div>

                                <div class="input-box">
                                    <label for="categoria_titulo" class="form-label">Categoria</label>
                                    <select
                                        name="categoria_titulo"
                                        id="categoria_titulo"
                                        class="form-control"
                                        required="required"
                                        value="<?php echo $linha['categoria_nome'];?>">
                                        <option value="">Selecione a categoria</option>
                                        <?php 
                                            $query="SELECT * FROM categoria ORDER BY codigo_categoria";
                                            $resultado=mysqli_query($conn, $query);

                                            while ($tabela=mysqli_fetch_assoc($resultado)) {
                                                if ($linha['categoria_codigo']==$tabela['codigo_categoria']) {
                                        ?>
                                        <option value="<?php echo $tabela['codigo_categoria'];?>" selected="selected"><?php echo $tabela['categoria_nome'];?></option>
                                    <?php
                                                }

                                                else {
                                        ?>

                                        <option value="<?php echo $tabela['codigo_categoria'];?>"><?php echo $tabela['categoria_nome'];?></option>
                                        <?php
                                                }
                                            }

                                        ?>
                                    </select>
                                </div>

                                <div class="input-box">
                                    <label for="editora_titulo" class="form-label">Editora</label>
                                    <select
                                        name="editora_titulo"
                                        id="editora_titulo"
                                        class="form-control"
                                        required="required"
                                        value="<?php echo $linha['editora_nome'];?>">
                                        <option value="">Selecione a editora</option>
                                        <?php 
                                            $query="SELECT * FROM editora ORDER BY codigo_editora";
                                            $resultado=mysqli_query($conn, $query);

                                            while ($tabela=mysqli_fetch_assoc($resultado)) {

                                            if ($linha['editora_codigo']==$tabela['codigo_editora']) {
                                        ?>
                                        <option value="<?php echo $tabela['codigo_editora'];?>" selected="selected"><?php echo $tabela['editora_nome'];?></option>
                                    <?php
                                            }

                                            else {
                                        ?>
                                        <option value="<?php echo $tabela['codigo_editora'];?>"><?php echo $tabela['editora_nome'];?></option>
                                        <?php
                                                }
                                             }

                                        ?>
                                    </select>
                                </div>

                                <div class="input-box">
                                    <label for="autor_titulo[]" class="form-label">Autor(es)</label>
                                    <select
                                        name="autor_titulo[]"
                                        id="autor_titulo[]"
                                        class="form-control multiple-checkboxes"
                                        multiple="multiple"
                                        required="required">
                                        <option value="">Selecione o(a) autor(a)</option>
                                        <?php 
                                            $query="SELECT * FROM autor ORDER BY codigo_autor";
                                            $resultado=mysqli_query($conn, $query);

                                            while ($tabela=mysqli_fetch_assoc($resultado)) {
                                              
                                                if ($linha['autor_codigo']==$tabela['codigo_autor']) {
                                        ?>

                                        <option value="<?php echo $tabela['codigo_autor'];?>" selected="selected"><?php echo $tabela['autor_nome'];?></option>

                                    <?php
                                                }

                                                else {
                                                    
                                        ?>
                                        <option value="<?php echo $tabela['codigo_autor'];?>"><?php echo $tabela['autor_nome'];?></option>

                                        <?php
                                                }
                                            }

                                        ?>
                                    </select>
                                </div>

                                <div class="input-box">
                                    <label for="autores_atuais" class="form-label">Autores Atuais</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        name="autores_atuais"
                                        id="autores_atuais"
                                        text-align="center"
                                        value="
                                            <?php $query="SELECT autor_nome from autor_titulo a_t, autor a where codigo_titulo_codigo = ".$linha['codigo_titulo']." and codigo_autor_codigo = a.codigo_autor";
                                            $result=mysqli_query($conn, $query);

                                            while($nomes=mysqli_fetch_assoc($result)) {
                                                echo $nomes['autor_nome'].";";
                                            }

                                        ?>">
                                </div>

                                <div class="input-box">
                                    <label for="descricao" class="form-label">Descrição</label><input
                                        type="text"
                                        class="form-control"
                                        name="descricao"
                                        id="descricao"
                                        placeholder="Informe a descrição do título"
                                        value="<?php echo $linha['descricao'];?>"></div>

                                <div class="input-box">
                                    <label for="qntdd_pagina" class="form-label">Quantidade Pagina</label>
                                    <input
                                        type="number"
                                        class="form-control formatado"
                                        name="qntdd_pagina"
                                        id="qntdd_pagina"
                                        placeholder="Informe a quantidade de páginas do título"
                                        required="required"
                                        value="<?php echo $linha['qntdd_pag'] ?>">
                                </div>

                                <div class="input-box">
                                    <label for="preco" class="form-label">Valor</label>
                                    <input
                                        type="text"
                                        class="form-control formatado"
                                        name="preco"
                                        id="preco"
                                        placeholder="Informe o valor do título"
                                        required="required"
                                        value="<?php echo $linha['valor'] ?>">
                                </div>
                              
                                <div class="input-box">

                                    <select name="status" id="status">
                                        <option value="">Selecione o status do livro</option>
                                        <option value="<?php echo $linha['status']?>" selected="selected"><?php echo $linha['status']?></option>
                                    <?php
                                    $status = $linha['status'];
                                    if($status == "Indisponivel"){
                                        echo "<option value='Disponivel'>Disponivel</option>";
                                        
                                    }
                                    else{
                                        echo "<option value='Indisponivel'>Indisponivel</option>";
                                    }
                                    ?>
                                    </select>
                                </div>

                            </div>

                        

                            <div class="login-button">
                                <input
                                    type="button"
                                    name="cancelar"
                                    class="btn btn-primary btn-block mt-3"
                                    id="btn"
                                    value="Cancelar"
                                    onclick="window.location.href='listar_titulo.php'">
                                <input
                                    type="submit"
                                    name="alterar"
                                    class="btn btn-primary btn-block mt-3"
                                    id="btn"
                                    value="alterar">
                            </div>

                        </form>
                    </div>
                </div>
            </main>
            <?php
            include_once('right_user.php');
            ?>
        </div>

    </body>

    <script>
        function previewImagem() {
            var imagem = document
                .querySelector('input[name=foto1]')
                .files[0];
            var preview = document.querySelector('img[name=visualizar]');
            var reader = new FileReader();

            reader.onloadend = function () {
                preview.src = reader.result;
            }

            if (imagem) {
                reader.readAsDataURL(imagem);
            } else {
                preview.src = "";
            }
        }
    </script>

    <script src="js/funcoes.js"></script>

</html>
<?php 
    if (isset($_POST['alterar'])) {
        if (!empty($_POST) && (empty($_POST['name']) || empty($_POST['editora_titulo']) || empty($_POST['categoria_titulo']) 
            || empty($_POST['qntdd_pagina'])) || empty($_POST['preco'])  || empty($_POST['status'])) {
                echo "<script type='text/javascript'>alert('Preencha todos os campos!');</script>";
                echo "<meta HTTP-EQUIV='refresh' CONTENT='0; URL=editar_titulo.php?id=$id'>";
        }
        else{
        
            $name=$_POST['name'];
            $editora=$_POST['editora_titulo'];
            $categoria=$_POST['categoria_titulo'];
            $descricao=$_POST['descricao'];
            $id=$_GET['id'];
            $qntdd_pag = $_POST['qntdd_pagina'];
            $preco =$_POST['preco'];
            $status = $_POST['status'];

            $query = "UPDATE titulo 
            SET categoria_codigo='$categoria',
            editora_codigo='$editora',
            descricao='$descricao',
            titulo_nome='$name',
            quantidade_pag = '$qntdd_pag',
            valor = '$preco',
            status = '$status';
            WHERE codigo_titulo = $id";
            $result1 = mysqli_query($conn, $query);
            var_dump($result1);
        

            if(!isset($_POST['autor_titulo[]'])) {
                $query="DELETE FROM autor_titulo WHERE codigo_titulo_codigo = $id";
                $row = mysqli_query($conn, $query);

                foreach($_POST['autor_titulo'] as $selected) {
                    $query="INSERT INTO autor_titulo VALUES($selected, $id)";
                    $row1 = mysqli_query($conn, $query);
                }

            }

            if ($row && $row1) {
                echo "<script type='text/javascript'>OpcaoMensagens(2);</script>";
                echo '<meta HTTP-EQUIV="Refresh" CONTENT="0; URL=listar_titulo.php">';
            }

            else {
                echo "<script type='text/javascript'>OpcaoMensagens(5);</script>";
                echo "<meta HTTP-EQUIV='refresh' CONTENT='0; URL=editar_titulo.php?id=$id'>";
            }
        }   
    }


?>