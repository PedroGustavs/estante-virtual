<?php
    if(isset($_GET['id'])){

        $id = $_GET['id'];
        session_start();
        $tipo = $_SESSION['tipo_acesso'];

        if(empty($tipo)){
            echo "<script type='text/javascript'>alert('Voce deve estar autenticado!');</script>";
            echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=livro.php?id=$id'>";    
        }
        else{
            if($tipo == "administrador"){
                echo "<script type='text/javascript'>alert('Apenas leitores podem comentar em livros!');</script>";
                echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=livro.php?id=$id'>";
            }
            else{
                 
                if(empty($_POST['comment'])){
                    echo "<script type='text/javascript'>alert('Preencha o campo para efetuar um comentário!');</script>";
                    echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=comentar.php?id=$id'>";
                }
                else{
                    include_once('conexao.php');
                    $coment = $_POST['comment'];
                    $cod = $_SESSION['idusuario'];
                    $query = "INSERT INTO `comentario`(`codigo_usuario_codigo`, `codigo_titulo_codigo`, `comentario`)
                    VALUES ('$cod', '$id', '$coment')";
                    $res = mysqli_query($conn, $query);                 

                    if($res){
                        echo "<script type='text/javascript'>alert('Comentário realizado com sucesso!');</script>";
                        echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=livro.php?id=$id'>";
                    }

                    else{
                        echo "<script type='text/javascript'>alert('Ocorreu um erro!');</script>";
                        echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=comentar.php?id=$id'>";
                    }

                }
                
            }
        }
    }   
    else{
        echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=index.php'>";
    }
?>
