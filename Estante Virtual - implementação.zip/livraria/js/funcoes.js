function confirmacaoDesfavoritar(id, op) {
	var resposta = confirm("Deseja desfavoritar esse livro?");
    if (resposta == true) {
		  window.location.href = "desfavoritar.php?id="+id;
    }
    else{
      if(op == 1){
        window.location.href = "listar_favoritados.php";
      }
    }
}
function EfetuarComentario(id){
  window.location.href = "livro.php?id="+id;
}

function excluir(id, num, comentario, favoritado){
  var resposta = confirm("Deseja solicitar a exclusao da conta?");
  if (resposta == true) {
    if(num > 0 || comentario > 0 || favoritado > 0){
      alert('Existem compras, comentarios ou livros favoritados associadas a voce')
      window.location.href = "configuracao.php";
    }
    else{
        window.location.href = "solicitar.php?id="+id; 
    }
  }
  else{
     window.location.href = "configuracao.php";

  }
}



function confirmacaoDescomentar(id, op, coment) {
	var resposta = confirm("Deseja excluir o comentário desse livro?");
    if (resposta == true) {
      window.location.href = "descomentar.php?id="+id+"&coment="+coment;      
    }
    else{
      if(op == 1){
        window.location.href = "livro.php?id="+id;
      }
    }
}
function confirmacaoDesfavoritar(id, op) {
	var resposta = confirm("Deseja desfavoritar esse livro?");
    if (resposta == true) {
		  window.location.href = "desfavoritar.php?id="+id;
    }
    else{
      if(op == 1){
        window.location.href = "listar_favoritados.php";
      }
    }
}

function ConfirmarExclusaoVenda(id){
  var resposta = confirm("Por gentileza, deseja excluir a venda?")
  if(resposta === true){
    window.location.href="deletar_venda.php?id="+id;
  }
}

function ConfirmarExclusaoCompra(id){
  var resposta = confirm("Por gentileza, deseja excluir a compra?")
  if(resposta === true){
    window.location.href="deletar_compra.php?id="+id;
  }
}

function LoginMensagem(){
  alert("Usuário e/ou Senha invalido(s)!");
  header("location: index.php");
  window.location.href='index.php';
}

function ConfirmarExclusaoCategoria(id){
  var resposta = confirm("Por gentileza, deseja excluir a categoria?")
  if(resposta === true){
    window.location.href="deletar_categoria.php?id="+id;
  }
}

function ConfirmarExclusaoFornecedor(id){
  var resposta = confirm("Por gentileza, deseja excluir o fornecedor?")
  if(resposta === true){
    window.location.href="deletar_fornecedor.php?id="+id;
  } 
}

function ConfirmarExclusaoTitulo(id){
  var resposta = confirm("Por gentileza, deseja excluir o título?")
  if(resposta === true){
    window.location.href="deletar_titulo.php?id="+id;
  } 
}

function ConfirmarExclusaoCidade(id){
  var resposta = confirm("Por gentileza, deseja excluir a cidade?")
  if(resposta === true){
    window.location.href="deletar_cidade.php?id="+id;
  } 
}

function ConfirmarExclusaoUsuario(id){
  var resposta = confirm("Por gentileza, deseja excluir o usuário?")
  if(resposta === true){
    window.location.href="deletar_usuario.php?id="+id;
  } 
}

function ConfirmarExclusaoEstado(id){
  var resposta = confirm("Por gentileza, deseja excluir o estado?")
  if(resposta === true){
    window.location.href="deletar_estado.php?id="+id;
  } 
}

function ConfirmarExclusaoAutor(id){
  var resposta = confirm("Por gentileza, deseja excluir o/a autor(a)?")
  if(resposta === true){
    window.location.href="deletar_autor.php?id="+id;
  }

}

function ConfirmarExclusaoEditora(id){
  var resposta = confirm("Por gentileza, deseja excluir a editora?")
  if(resposta === true){
    window.location.href="deletar_editora.php?id="+id;
  }

}
function OpcaoMensagens($id){
  if ($id === 1){
    window.alert('Registro salvo com sucesso!');
  }
  if ($id === 2){
    window.alert('Registro alterado com sucesso!');
  }
  if ($id === 3){
    window.alert('Registro excluido com sucesso!');
  }
  if ($id === 4){
    window.alert('Registro já cadastrado!');
  }
  if ($id === 5){
    window.alert('Ocorreu um erro!');
  }
}

function SessaoExpirada() {
  alert("WebSite diz: \nSua Sessão foi Expirada!");
}