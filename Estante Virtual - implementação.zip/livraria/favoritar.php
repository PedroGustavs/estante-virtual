<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Favoritar</title>
        <script src="js/funcoes.js"></script>
    </head>
    <body>
        <?php
            $id = $_GET['id'];
            if($id > 0){
                session_start();
                if(empty($_SESSION['tipo_acesso'])){
                    echo "<script type='text/javascript'>alert('Voce não está autenticado!');</script>";
                    echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=index.php'>";
                }
                else{
                    if($_SESSION['tipo_acesso'] == "administrador"){         
                        echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=index.php'>";
                    }
                    else{
               
                        include_once('conexao.php');
                        $codigo = $_SESSION['idusuario'];

                        $query = "SELECT *
                        FROM favoritado
                        WHERE codigo_usuario_codigo  = $codigo
                        AND codigo_titulo_codigo = $id";
                        $dados = mysqli_query($conn, $query);
                        $num = mysqli_num_rows($dados);

                        if($num > 0){
                          echo "<script type='text/javascript'>confirmacaoDesfavoritar($id);</script>";
                        }
                        else{
                            $comandoParaInsercao = "INSERT INTO `favoritado`(`codigo_usuario_codigo`, `codigo_titulo_codigo`)
                            VALUES ('$codigo', '$id')";     
                            $resultado = mysqli_query($conn, $comandoParaInsercao);

                            if($resultado){
                                echo "<script type='text/javascript'>alert('Livro Favoritado com Sucesso!');</script>";
                                echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=livro.php?id=$id'>";                   
                            }else{
                                echo "<script type='text/javascript'>alert('Erro ao Favoritar!');</script>";
                                echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=livro.php?id=$id'>";
                            }                
                        }
                    }
                }
            
            }
            else{
                echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=index.php'>";
            }      
        ?>
    </body>
</html>
