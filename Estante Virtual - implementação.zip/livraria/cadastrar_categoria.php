<?php
  session_start();
  include_once('sessao.php');//verifica se tem sessão e se está tudo ok!
  //chama a conecao com banco de dados
  include_once('conexao.php');
  $exibirTipodeAcesso = $_SESSION['tipo_acesso'];//recebe o tipo de acesso

if($exibirTipodeAcesso != "administrador"){
    header("location:dashboard.php");
    echo "<script type='text/javascript'>alert('Apenas o Administrador possui acesso a essa área!');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cadastro Categoria</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="css/button.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>
        <div class="container">
            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">
                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="listar_categoria.php">Listagem Categoria</a>
                        </span>
                        <span>
                            >
                            <a href="cadastrar_categoria.php">Cadastrar Categoria</a>
                        </span>
                    </span>
                </div>
                <div class="recent-users">

                    <div class="form form1">
                        <h2 class="crud">Cadastro Categoria</h2>
                        <form action="#" method="post">
                            <div class="input-group">
                                <div class="input-box">
                                    <label for="nome" class="form-label">Nome</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        name="nome"
                                        id="nome"
                                        placeholder="Informe o nome da categoria">
                                </div>
                            </div>

                            <div class="login-button">
                                <input
                                    type="button"
                                    name="cancelar"
                                    class="btn btn-primary btn-block mt-3"
                                    id="btn"
                                    value="Cancelar"
                                    onclick="window.location.href='listar_categoria.php'">
                                <input
                                    type="submit"
                                    name="cadastrar"
                                    class="btn btn-primary btn-block mt-3"
                                    id="btn"
                                    value="Cadastrar">
                            </div>

                        </form>
                    </div>

                </div>
            </main>

            <?php
            include_once('right_user.php');
            ?>
        </div>
    </body>
    <script src="js/funcoes.js"></script>
</html>

<?php
    if (isset($_POST['cadastrar'])) {
        if (!empty($_POST) && (empty($_POST['nome']))){
            echo "<script type='text/javascript'>alert('Preencha todos os campos!');</script>";
            echo '<meta HTTP-EQUIV="refresh" CONTENT="0; URL=cadastrar_categoria.php">';
        }
        else{
            $nome = $_POST['nome'];
            $query = "SELECT categoria_nome 
            FROM categoria 
            WHERE categoria.categoria_nome = '$nome'";
            $row = mysqli_query($conn, $query);
            $num = mysqli_num_rows($row);

            if($num > 0){
                echo "<script type='text/javascript'>alert('Categoria já cadastrada!');</script>";
                echo '<meta HTTP-EQUIV="Refresh" CONTENT="0 URL=cadastrar_categoria.php">';
            }
            else{
                $comandoParaInsercao = "INSERT INTO `categoria`(`categoria_nome`) VALUES ('$nome')";     
                $resultado = mysqli_query($conn, $comandoParaInsercao); //executa o codigo acima no banco

                if($resultado){
                    echo "<script type='text/javascript'>OpcaoMensagens(1);</script>";
                    echo '<meta HTTP-EQUIV="Refresh" CONTENT="0; URL=listar_categoria.php">';
                }else{
                    echo "<script type='text/javascript'>alert('Erro ao inserir!');</script>";
                }  
            } 
        }
    }
?>
</html>