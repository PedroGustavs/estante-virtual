<?php
session_start();
include_once('sessao.php');
include_once('conexao.php');
$exibirTipodeAcesso = $_SESSION['tipo_acesso'];//recebe o tipo de acesso

if($exibirTipodeAcesso != "administrador"){
    header("location:dashboard.php");
    echo "<script type='text/javascript'>alert('Apenas o Administrador possui acesso a essa área!');</script>";
}

?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Listagem da(s) Editora(s)</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="css/button.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>
        <div class="container">
            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">
                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>
                        <span>
                        >
                    </span>
                    <span>
                        <a href="listar_editora.php">Listagem Editora</a>
                    </span>
                    </span>



                </div>

                <div class="recent-users">
                    <h2 class="crud">Listagem de Editora</h2>

                    <table>
                        <thead>
                            <tr>
                                <th>Codigo</th>
                                <th>Nome</th>
                                <th>Email</th>
                                <th>Telefone</th>
                                <th>Rua</th>
                                <th>Número</th>
                                <th>Bairro</th>
                                <th>CEP</th>
                                <th>Cidade</th>
                                <th>Estado</th>
                                <th>Ações</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                                $query = "SELECT * FROM editora ORDER BY codigo_editora";
                                $row = mysqli_query($conn, $query);
                                while($dados = mysqli_fetch_assoc($row)){
                            ?>

                            <tr>
                                <td><?php echo $dados['codigo_editora']; ?></td>
                                <td><?php echo $dados['editora_nome'];?></td>
                                <td><?php echo $dados['email'];?></td>
                                <td><?php echo $dados['telefone'];?></td>
                                <td><?php echo $dados['rua']; ?></td>
                                <td><?php echo $dados['numero']; ?></td>
                                <td><?php echo $dados['bairro']; ?></td>
                                <td><?php echo $dados['cep']; ?></td>
                                <td><?php echo $dados['cidade']; ?></td>
                                <td><?php echo $dados['estado']; ?></td>
                                
                                
                                
                                <td>
                                    <div class="td">
                                        <?php 
                                                echo"<a href='editar_editora.php?id=".$dados['codigo_editora']."' title='Alterar'>
                                                        <i class='fa fa-edit fa-2x'></i>
                                                    </a>";

                                                $id = $dados['codigo_editora'];
                                                echo"<a href='#' onclick='ConfirmarExclusaoEditora($id)' title='Excluir'>
                                                <i class='fa fa-trash fa-2x'></i>
                                                </a>";
                                            ?>
                                    </div>
                                </td>
                            </tr>

                            <?php
                                }
                            ?>
                        </tbody>
                    </table>

                    <div class="btn-box">
                        <input
                            type="button"
                            name="Cadastrar"
                            class="btn btn-primary pull-center"
                            value="Cadastrar Editora"
                            id="btn"
                            onclick="window.location.href='cadastrar_editora.php'">
                    </div>
                </div>
            </main>

            <?php
            include_once('right_user.php');
            ?>
        </div>
    </body>
    <script src="js/funcoes.js"></script>
</html>