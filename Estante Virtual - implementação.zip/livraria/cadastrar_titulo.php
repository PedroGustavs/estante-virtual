<?php
  session_start();
  include_once('sessao.php');//verifica se tem sessão e se está tudo ok!
  //chama a conecao com banco de dados
  include_once('conexao.php');
  $exibirTipodeAcesso = $_SESSION['tipo_acesso'];

if($exibirTipodeAcesso != "administrador"){
    header("location:dashboard.php");
    echo "<script type='text/javascript'>alert('Apenas o Administrador possui acesso a essa área!');</script>";
}
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cadastro Título</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="css/button.css">

        <link
            href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap"
            rel="stylesheet">
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.js"></script>
        <script
            src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/js/bootstrap-multiselect.js"></script>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-multiselect/0.9.13/css/bootstrap-multiselect.css">
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>
        <div class="container">
            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">
                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="listar_titulo.php">Listagem Título</a>
                        </span>
                        <span>
                            >
                            <a href="cadastrar_titulo.php">Cadastrar Título</a>
                        </span>
                    </span>
                </div>

                <div class="recent-users">
                    <div class="form form2">
                        <form action="" method="post" enctype="multipart/form-data">
                            <h2 class="crud">Cadastrar Título</h2>

                            <h1>Dados do Título</h1>

                            <div class="input-group grid1">

                                <div class="input-box">
                                    <label for="name_titulo[]" class="form-label">Nome</label>
                                    <input
                                        type="text"
                                        class="form-control formatado"
                                        name="name_titulo"
                                        id="name_titulo"
                                        maxlength="40"
                                        placeholder="Informe o nome do título"
                                        required="required">
                                </div>

                                <div class="input-box">
                                    <label for="autor_titulo[]" class="form-label">Autor(es)</label>

                                    <select
                                        id="autor_titulo[]"
                                        name="autor_titulo[]"
                                        class="form-control"
                                        multiple>
                                        <?php
                                        $query = "SELECT * FROM autor ORDER BY codigo_autor";
                                        $resultado = mysqli_query($conn, $query);
                                        while ($linha = mysqli_fetch_assoc($resultado)) {
                                    ?>

                                        <option value="<?php echo $linha['codigo_autor'];?>">
                                            <?php echo $linha['autor_nome'];?>
                                        </option>

                                        <?php
                                    }
                                ?>

                                    </select>
                                </div>

                                <div class="input-box">
                                    <label for="categoria_titulo" class="form-label">Categoria</label>
                                    <select
                                        name="categoria_titulo"
                                        id="categoria_titulo"
                                        class="form-control">
                                        <option value="" selected="selected">Selecione a categoria</option>
                                        <?php
                                        $query = "SELECT * FROM categoria ORDER BY codigo_categoria";
                                        $resultado = mysqli_query($conn, $query);
                                        while ($linha = mysqli_fetch_assoc($resultado)) {
                                    ?>

                                        <option value="<?php echo $linha['codigo_categoria'];?>">
                                            <?php echo $linha['categoria_nome'];?>
                                        </option>

                                        <?php
                                    }
                                ?>
                                    </select>
                                </div>

                                <div class="input-box">
                                    <label for="editora_titulo" class="form-label">Editora</label>
                                    <select
                                        name="editora_titulo"
                                        id="editora_titulo"
                                        class="form-control">
                                        <option value="" selected="selected">Selecione a editora</option>
                                        <?php
                                        $query = "SELECT * FROM editora ORDER BY codigo_editora";
                                        $resultado = mysqli_query($conn, $query);
                                        while ($linha = mysqli_fetch_assoc($resultado)) {
                                    ?>

                                        <option value="<?php echo $linha['codigo_editora'];?>">
                                            <?php echo $linha['editora_nome'];?>
                                        </option>

                                        <?php
                                    }
                                ?>
                                    </select>
                                </div>

                               

                                <div class="input-box">
                                    <label for="qntdd_pagina" class="form-label">Quantidade Pagina</label>
                                    <input
                                        type="number"
                                        class="form-control formatado"
                                        name="qntdd_pagina"
                                        id="qntdd_pagina"
                                        placeholder="Informe a quantidade de páginas do título">
                                </div>

                                <div class="input-box">
                                    <label for="preco" class="form-label">Valor</label>
                                    <input
                                        type="text"
                                        class="form-control formatado"
                                        name="preco"
                                        id="preco"
                                        placeholder="Informe a preço unitário do título">
                                </div>
                            </div>

                            <h1>Outras informações</h1>
    
                                <div class="input-box">
                                    <label for="message" class="form-label">Descrição</label>
                                    <textarea name="message" class="message"id="message" cols="10" rows="10"></textarea>                                      
                                </div>

                                <div class="input-box">
                                    <label for="foto">Imagem</label>
                                        <input type="file" required="required" name="foto" id="foto" onchange="previewImagem()">
                                        <img  name='visualizar' id='visualizar' width='200px' height='200px'>
                                </div>
                            

                            <div class="login-button">
                                <input
                                    type="button"
                                    name="cancelar"
                                    class="btn btn-primary btn-block mt-3"
                                    id="btn"
                                    value="Cancelar"
                                    onclick="window.location.href='listar_titulo.php'">
                                <input
                                    type="submit"
                                    name="cadastrar"
                                    class="btn btn-primary btn-block mt-3"
                                    id="btn"
                                    value="Cadastrar">
                            </div>

                        </form>
                    </div>

                </div>
            </main>

            <script>
            function previewImagem(){
                var imagem = document.querySelector('input[name=foto]').files[0];
                var preview = document.querySelector('img[name=visualizar]');
                var reader = new FileReader();

                reader.onloadend = function() {
                    preview.src = reader.result;
                }

                if(imagem){
                    reader.readAsDataURL(imagem);
                } else {
                    preview.src = "";
                }
            }
            </script>

            <?php
            include_once('right_user.php');
            ?>
        </div>
    </body>
    <script src="js/funcoes.js"></script>
</html>

<?php
    //se ele clicou no botão salvar
        if (isset($_POST['cadastrar'])) {    
            // echo "foi";
            // exit;         
            if (isset($_FILES['foto']['name']) && $_FILES['foto']['error'] == 0) {
                $arquivo_tmp = $_FILES['foto']['tmp_name'];
                $nome = $_FILES['foto']['name'];//images.png
                $extensao = strrchr($nome, '.');//png
                $extensao = strtolower($extensao);
                if (strstr('.svg;.pdf;.png;.jpg;.jpeg;.gif', $extensao)) {
                    $novoNome = md5(microtime()) . '.' . $extensao;
                    $destino = 'imageTitle/' . $novoNome;
                    if (@move_uploaded_file($arquivo_tmp, $destino)) {
                        echo "Arquivo salvo com sucesso";
                    } else {
                        echo "Erro ao salvar o arquivo";
                    }           
                } else {
                    echo "Formato de arquivo invalido!";
                }            
            }
            // exit;            

            $descricao = $_POST['message'];
            $categoria = $_POST['categoria_titulo'];
            $editora = $_POST['editora_titulo'];
            $nome = $_POST['name_titulo'];
            $preco = number_format($_POST['preco'], 2, '.', '');
            $pag = $_POST['qntdd_pagina'];
            $img_livro = $novoNome;

            /* $data_nasc = $_POST['data']; // 19/01/1980
            $dataBrasil = implode('-', arr""ay_reverse(explode('/', "$data_nasc")));// 1980-01-19*/
            
            $status = "Indisponivel";

            $comandoParaInsercao = "INSERT INTO `titulo`(`categoria_codigo`, `editora_codigo`, `descricao`,`titulo_nome`, `qntdd_pag`, `valor`, `foto`, `status`)
            VALUES ('$categoria', '$editora', '$descricao', '$nome', '$pag', '$preco', '$img_livro', '$status')";                 
            $resultado = mysqli_query($conn, $comandoParaInsercao);

            $query = "SELECT codigo_titulo FROM titulo ORDER BY codigo_titulo DESC LIMIT 1";
            $result = mysqli_query($conn, $query); 

            while($row = mysqli_fetch_assoc($result)){
                $codigoTitulo = $row['codigo_titulo'];
            }

            if(!isset($_POST['autor_titulo[]'])){

                foreach($_POST['autor_titulo'] as $selected){
                $codigoAutor = $selected;               
                $comando = "INSERT INTO `autor_titulo`(`codigo_autor_codigo`, `codigo_titulo_codigo`)
                VALUES ('$codigoAutor', '$codigoTitulo')";
                $resultado1 = mysqli_query($conn, $comando);
                }
            }

            if($resultado && $resultado1){
                echo "<script type='text/javascript'>OpcaoMensagens(1);</script>";
                echo '<meta HTTP-EQUIV="Refresh" CONTENT="0 URL=listar_titulo.php">';
            }else{
                echo "<script type='text/javascript'>alert('Erro ao inserir!');</script>";
            }   

                
            
        }
        
    ?>