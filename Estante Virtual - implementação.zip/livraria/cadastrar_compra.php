<?php
session_start();
include_once('sessao.php');
include_once('conexao.php');
$exibirTipodeAcesso = $_SESSION['tipo_acesso'];
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Cadastro Compra</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="css/button.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>

    <div class="container">
        <?php include_once('menu_user.php')?>

        <main>
            <div class="link">
                <span>
                    <a href="dashboard.php">
                        Dashboard
                    </a>
                    <span>
                        >
                        <a href="gerenciar_compra.php">Compras</a>
                        >
                        <a href="cadastrar_compra.php">Cadastrar Compra</a>
                    </span>

                </span>
            </div>

            <div class="recent-users">
                    <div class="form form1">
                        <form id="form" action="#" method="post">
                        <h2 class="crud">Cadastrar Compra</h2>

                            <h1>Dados da Compra</h1>

                            <div class="input-group grid1">

                            <div class="input-box">
                                    <label for="fornecedor" class="form-label">Fornecedor</label>
                                    <select
                                        name="fornecedor"
                                        id="fornecedor"
                                        class="form-control">
                                        <option value="" selected="selected">Selecione a fornecedor</option>
                                        <?php
                                        $query = "SELECT * FROM fornecedor ORDER BY codigo_fornecedor";
                                        $resultado = mysqli_query($conn, $query);
                                        while ($linha = mysqli_fetch_assoc($resultado)) {
                                    ?>

            <option value="<?php echo $linha['codigo_fornecedor'];?>">
                <?php echo $linha['fornecedor_nome'];?>
            </option>

            <?php
        }
    ?>
        </select>
    </div>
    
    <div class="input-box">
        <label for="titulo" class="form-label">Título</label>
        <select
            name="titulo"
            id="titulo"
            class="form-control">
            <option value="" selected="selected">Selecione o título</option>
            <?php
            $query = "SELECT * FROM titulo ORDER BY codigo_titulo";
            $resultado = mysqli_query($conn, $query);
            while ($linha = mysqli_fetch_assoc($resultado)) {
        ?>

            <option value="<?php echo $linha['codigo_titulo'];?>">
                <?php echo $linha['titulo_nome'];?>
            </option>

            <?php
        }
    ?>
        </select>
    </div>
    
    <div class="input-box">
        <label for="data" class="form-label">Data da Compra</label>
        <input type="date" name="data" id="data" placeholder="informe o data da compra">
    </div>

    <div class="input-box">
        <label for="preco" class="form-label">Preço</label>
        <input type="number" name="preco" id="preco" placeholder="informe o preço da compra">
    </div>                              
</div>

<div class="login-button">
<input type="button" name="cancelar" class="btn btn-primary btn-block mt-3" id="btn"
    value="Cancelar" onclick="window.location.href='gerenciar_compra.php'">
<input type="submit" name="cadastrar" class="btn btn-primary btn-block mt-3" id="btn"
    value="Cadastrar">
</div>
                           

                        </form>
                    </div>

                </div>
            </main>

            <?php
            include_once('right_user.php');
            ?>
        </div>             
    </body>
    <script src="js/funcoes.js"></script>
    <script src="js/formulario.js"></script>
</html>

<?php
    if (isset($_POST['cadastrar'])) {
        if(!empty($_POST) && (empty($_POST['fornecedor'])) || empty($_POST['data']) 
        || empty($_POST['preco']) || empty($_POST['titulo'])    ){
            echo "<script type='text/javascript'>alert('Preencha todos os campos!');</script>";
            echo '<meta HTTP-EQUIV="refresh" CONTENT="0; URL=cadastrar_compra.php">';        
        }
        else{  
            $fornecedor = $_POST['fornecedor'];
            $titulo = $_POST['titulo'];
            $preco = $_POST['preco'];

            if($preco <= 0){
                echo "<script type='text/javascript'>alert('O preço deve ser maior que zero!');</script>";
                echo '<meta HTTP-EQUIV="Refresh" CONTENT="0 URL=cadastrar_compra.php">';
            }
            else{
                    $data = $_POST['data'];
                    $dataBrasil = implode('-', array_reverse(explode('/', "$data")));
                    $codigo = $_SESSION['idusuario'];                
                    $comandoParaInsercao = "INSERT INTO `compra`(`codigo_usuario_codigo`, `codigo_fornecedor_codigo`,`data`)
                    VALUES ('$codigo', '$fornecedor', '$dataBrasil')";                
                    $resultado = mysqli_query($conn, $comandoParaInsercao); //executa o codigo acima no banco

                    $query = "SELECT codigo_compra FROM compra ORDER BY codigo_compra DESC LIMIT 1";
                    $resultado1 = mysqli_query($conn, $query); 

                    while($row = mysqli_fetch_assoc($resultado1)){
                        $codigoCompra = $row['codigo_compra'];
                    }

                    $comandoParaInsercao = "INSERT INTO `itemcompra`(`codigo_compra_codigo`, `codigo_titulo_codigo`, `preco`)
                    VALUES ('$codigoCompra', '$titulo', '$preco')";                
                    $resultado2 = mysqli_query($conn, $comandoParaInsercao);

                    $status = "Disponivel";
                    $query = "UPDATE titulo 
                    SET titulo.status = '$status' 
                    WHERE codigo_titulo = $titulo";
                    $resultado3 = mysqli_query($conn, $query);

                    if($resultado && $resultado1 && $resultado2 && $resultado3){
                         echo "<script type='text/javascript'>OpcaoMensagens(1);</script>";
                        echo '<meta HTTP-EQUIV="Refresh" CONTENT="0; URL=gerenciar_compra.php">';
                    }
                    else{
                        echo "<script type='text/javascript'>alert('Ocorreu um erro!');</script>";
                        echo '<meta HTTP-EQUIV="Refresh" CONTENT="0; URL=gerenciar_compra.php">';
                    }

                       
                }

                 
            
                
                
        }
    } 
?>