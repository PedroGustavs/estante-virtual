<?php
    // Código para conexão com o banco e dados
    $servidor = "localhost";
    $usuario = "root";
    $senha = "ifsp";
    $dbname = "livraria";

    //Criar a conexão
    $conn = mysqli_connect($servidor, $usuario, $senha, $dbname);
?>