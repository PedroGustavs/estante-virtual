<?php
  session_start();
  include_once('sessao.php');//verifica se tem sessão e se está tudo ok!
  $exibirTipodeAcesso = $_SESSION['tipo_acesso'];//recebe o tipo de acesso
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Conta e Segurança</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>

        <div class="container">

            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">

                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="configuracao.php">Configuração</a>
                        </span>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="conta_seguranca.php">Conta e Segurança</a>
                        </span>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="meu_perfil.php">Meu Perfil</a>
                        </span>
                    </span>
                </div>

                <div class="recent-users">

                    <table>
                        <h2 class="crud">Dados Pessoais</h2>
                        <thead>
                            <tr>
                                <th>Codigo</th>
                                <th>Nome</th>
                                <th>Imagem</th>
                                <th>Email</th>
                                <th>Telefone</th>
                                <th>Rua</th>
                                <th>Número</th>
                                <th>Bairro</th>
                                <th>CEP</th>
                                <th>Cidade</th>
                                <th>Estado</th>
                                <th>Tipo acesso</th>
                                <th>Ações</th>
                            </tr>
                        </thead>

                        <tbody>
                            <td><?php echo $_SESSION['idusuario'];?></td>
                            <td><?php echo $_SESSION['nome'];?></td>
                            <td><img
                                        src="imageTitle/<?php echo $_SESSION['foto'];?>"
                                        alt="Imagem"
                                        width="80px"
                                        heigth="90px"></td>
                            <td><?php echo $_SESSION['email'];?></td>
                            <td><?php echo $_SESSION['telefone'];?></td>
                            <td><?php echo $_SESSION['rua'];?></td>
                            <td><?php echo $_SESSION['numero'];?></td>
                            <td><?php echo $_SESSION['bairro'];?></td>
                            <td><?php echo $_SESSION['cep'];?></td>
                            <td><?php echo $_SESSION['cidade'];?></td>
                            <td><?php echo $_SESSION['estado'];?></td>
                            <td><?php echo $_SESSION['tipo_acesso'];?></td>
                            <td>
                                <div class="td">
                                    <?php 
                                                echo"<a href='editar_usuario.php?id=".$_SESSION['idusuario']."' title='Alterar'>
                                                        <i class='fa fa-edit fa-2x'></i>
                                                    </a>";
                                                
                                                echo"<a href='#' title='Excluir'>
                                                <i class='fa fa-trash fa-2x'></i>
                                                </a>";
                                            ?>
                                </div>
                            </td>

                        </tbody>

                    </main>

                   
                </div>
            </body>
        </html>