<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Complete Responsive Online Boot Store Website Design Tutorial</title>
        <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <script src="https://kit.fontawesome.com/628c8d2499.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/carrinho.css">
        <script src="js/funcoes.js"></script>
    </head>

    <body>
    <?php
            include_once("conexao.php");

            $email = $_POST['email'];
            $senha = $_POST['senha'];

            if (!empty($_POST) && (empty($_POST['email']) || empty($_POST['senha']))) {
                echo "<script type='text/javascript'>alert('Preencha todos os campos!');</script>";
                echo '<meta HTTP-EQUIV="refresh" CONTENT="0; URL=index.php">';
            }

            else {
                session_start();
                $email_escape = addslashes($email);
                $senha_escape = addslashes($senha);

                $sql = "SELECT * FROM usuario WHERE email = '{$email_escape}' LIMIT 1";
                $query = mysqli_query($conn, $sql);
                $nivel = mysqli_fetch_assoc($query);

                if ( mysqli_affected_rows($conn) > 0 ) {

                    if (password_verify($senha_escape, $nivel['senha'])) {
                    
                    $_SESSION['idusuario'] = $nivel['codigo_usuario'];
                    $_SESSION['nome']  = $nivel['usuario_nome'];                 
                    $_SESSION['email'] = $nivel['email'];
                    $_SESSION['senha'] = $nivel['senha'];                  
                    $_SESSION['telefone'] = $nivel['telefone'];
                    $_SESSION['tipo_acesso'] = $nivel['tipo'];
                    $_SESSION['cidade'] = $nivel['cidade'];
                    $_SESSION['estado'] = $nivel['estado'];
                    $_SESSION['rua'] = $nivel['rua'];
                    $_SESSION['numero'] = $nivel['numero'];
                    $_SESSION['bairro'] = $nivel['rua'];
                    $_SESSION['cep'] = $nivel['cep'];
                    $_SESSION['foto'] = $nivel['foto_user'];
                    $_SESSION['carrinho'] = null;
                    $_SESSION['sessiontime'] = time() + 60 * 30;
                    header("location: index.php");   
                    } else{
                        echo "<script>LoginMensagem();</script>";
                        echo '<meta HTTP-EQUIV="refresh" CONTENT="0; URL=sair.php">';
                    }                 
                    
                } else {
                    echo "<script type='text/javascript'>alert('Email ou Senha Inválidos!');</script>";
                    echo '<meta HTTP-EQUIV="refresh" CONTENT="0; URL=sair.php">';
                }
            }
                        
        ?>
        <script src="js/funcoes.js"></script>
    </body>

</hmtl>