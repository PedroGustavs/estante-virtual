<?php
include_once('conexao.php');
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Estante Virtual</title>

        <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
            <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="css/header.css">
        <link rel="stylesheet" href="css/btn.css">
        <link rel="stylesheet" href="css/login.css">
        <link rel="stylesheet" href="css/section.css">

    </head>

    <body>
        <?php
            include_once('cabecario.php');
            include_once('login.php');        
        ?>

        <section class="home" id="home">
            <div class="row">

                <div class="swiper books-slider">
                <div class="swiper-wrapper">

                    <?php
                        $query = "SELECT t.*
                        FROM titulo t, categoria c, autor a, autor_titulo a_t, editora e
                        WHERE t.editora_codigo = e.codigo_editora
                        AND t.categoria_codigo = c.codigo_categoria
                        AND a.codigo_autor = a_t.codigo_autor_codigo
                        AND t.codigo_titulo = a_t.codigo_titulo_codigo
                        ORDER BY t.codigo_titulo";
                        $row = mysqli_query($conn, $query);
                        $num = mysqli_num_rows($row);

                        while($dados = mysqli_fetch_assoc($row)){
                    ?>
                   
                        <a href="livro.php?id=<?php echo $dados['codigo_titulo']?>" class="swiper-slide"><img src="imageTitle/<?php echo $dados['foto'];?>" alt="Imagem"></a>
                    

                    <?php
                    }

                    ?>


                </div>

                    <img src="image/stand.png" class="stand" alt="">
            </div>
        </section>

        <section class="icons-container">

            <div class="icons">
                <i class="fas fa-lock"></i>
                <div class="content">
                    <h3>Pagamento Seguro</h3>
                    <p>Negocie diretamente com o vendedor</p>
                </div>
            </div>

            <div class="icons">
                <i class="fas fa-headset"></i>
                <div class="content">
                    <h3>24/7 suporte</h3>
                    <p>nos chame qualquer hora</p>
                </div>
            </div>

        </section>

       

        <section class="featured" id="featured">

            <h1 class="heading">
                <span>Novidades que voce precisa conheçer</span>
            </h1>
        
            <div class="swiper featured-slider">

                <div class="swiper-wrapper">
                        <?php

                            $query = "SELECT t.*
                            FROM titulo t, categoria c, autor a, autor_titulo a_t, editora e
                            WHERE t.editora_codigo = e.codigo_editora
                            AND t.categoria_codigo = c.codigo_categoria
                            AND a.codigo_autor = a_t.codigo_autor_codigo
                            AND t.codigo_titulo = a_t.codigo_titulo_codigo
                            ORDER BY t.codigo_titulo";
                            $row = mysqli_query($conn, $query);
                            $num = mysqli_num_rows($row);

                          

                            while($dados = mysqli_fetch_assoc($row)){
                        ?>
                    <div class="swiper-slide box">
                        <div class="icons">                           
                            <?php
                                
                                $titulo = $dados['codigo_titulo'];
                                echo"<a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                    <i class='fa-solid fa-heart'></i>  
                                </a>";
                                echo"<a href='livro.php?id=".$dados['codigo_titulo']."' class='fas fa-eye'></a>";
                            ?>
                        </div>
                        
                        <div class="image">
                            <img src="imageTitle/<?php echo $dados['foto'];?>" alt="Imagem">
                        </div>

                        <div class="content">
                            <h3><?php echo $dados['titulo_nome'] ?></h3>
                            <div class="price">
                                <h1>R$<?php echo number_format($dados['valor'], 2, ',', '.')?></h1>
                                <h4><?php echo $dados['status'];?></h4>
                            </div>                            
                        </div>
                    </div>
                    <?php
                            }
                        
                    ?>
           
                    
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </section>

        <section class="featured1" id="featured1">

            <h1 class="heading">
                <span>Os mais populares</span>
            </h1>

            <div class="swiper featured-slider">

                <div class="swiper-wrapper">

                        <?php
                            $query = "SELECT COUNT(*) AS qntd_vendido, codigo_titulo, titulo_nome, foto, preco, valor, status
                            FROM titulo, venda, itemvenda, usuario
                            WHERE codigo_titulo = codigo_titulo_codigo
                            AND codigo_venda = codigo_venda_codigo
                            AND codigo_usuario = codigo_usuario_codigo
                            GROUP BY codigo_venda 
                            ORDER BY qntd_vendido DESC LIMIT 9";         
                            $result = mysqli_query($conn, $query);
                            $num = mysqli_num_rows($result);
                            echo $num;

                            while($dados = mysqli_fetch_assoc($result)){

                        ?>
                                <div class="swiper-slide box">
                        <div class="icons">                           
                            <?php
                               
                                $titulo = $dados['codigo_titulo'];
                                echo"<a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                    <i class='fa-solid fa-heart'></i>  
                                </a>";
                                echo"<a href='livro.php?id=".$dados['codigo_titulo']."' class='fas fa-eye'></a>";
                            ?>
                        </div>
                        
                        <div class="image">
                            <img src="imageTitle/<?php echo $dados['foto'];?>" alt="Imagem">
                        </div>

                        <div class="content">
                            <h3><?php echo $dados['titulo_nome'] ?></h3>
                            <div class="price">
                                <h1>R$<?php echo number_format($dados['valor'], 2, ',', '.')?></h1>
                                <h4><?php echo $dados['status']?></h4>
                            </div>                            
                        </div>
                    </div>

            <?php
            }
           
            ?>
            </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>

        </section>


                <?php
            include_once('rodape.php');
        ?>

        <script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

        <script src="js/script.js"></script>

    </body>

</html>