<?php

    if (!isset($_SESSION['email']) && !isset($_SESSION['senha'])) {
        session_destroy();
        unset($_SESSION['idusuario']);
        unset($_SESSION['nome']);
        unset($_SESSION['email']);
        unset($_SESSION['senha']);
        unset($_SESSION['tipo_acesso']);
        unset($_SESSION['telefone']);
        unset($_SESSION['cidade']);
        unset($_SESSION['estado']);
        unset($_SESSION['foto']);
        header("location: index.php");
    } else {
        if (isset($_SESSION['sessiontime'])) {
            if (isset($_SESSION['sessiontime']) < time()) {
                session_destroy();
                unset($_SESSION['idusuario']);
                unset($_SESSION['nome']);
                unset($_SESSION['email']);
                unset($_SESSION['senha']);
                unset($_SESSION['tipo_acesso']);
                unset($_SESSION['telefone']);
                unset($_SESSION['cidade']);
                unset($_SESSION['estado']);

                unset($_SESSION['foto']);
                header("location: index.php");
                echo "<script type='text/javascript'>SessaoExpirada();</script>";
            } else {
                $_SESSION["sessiontime"] = time() + 60 * 30;
            }
        } else {
            session_destroy();
            unset($_SESSION['idusuario']);
            unset($_SESSION['nome']);
            unset($_SESSION['email']);
            unset($_SESSION['senha']);
            unset($_SESSION['tipo_acesso']);
            unset($_SESSION['telefone']);
            unset($_SESSION['cidade']);
            unset($_SESSION['estado']);
            unset($_SESSION['foto']);
            header("location: index.php");
            echo "<script type='text/javascript'>SessaoExpirada();</script>";
        }
    } 
?>