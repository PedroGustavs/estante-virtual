<?php
  include_once('conexao.php');
 
 $id=$_GET['id'];
 $i = 0;
 if (isset($id)) {

     $query = "SELECT c.*, e.*, t.*, a.*, a_t.*
     FROM autor a, categoria c, editora e, titulo t, autor_titulo a_t
     WHERE a_t.codigo_autor_codigo = a.codigo_autor
     AND t.editora_codigo = e.codigo_editora 
     AND t.categoria_codigo = c.codigo_categoria 
     AND a_t.codigo_titulo_codigo = t.codigo_titulo
     AND t.codigo_titulo = $id 
     AND a_t.codigo_titulo_codigo = $id";
     $dados = mysqli_query($conn, $query);
     $linha = mysqli_fetch_assoc($dados);
 }
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">

        <title>Estante Virtual</title>

        <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
            <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>

        <link rel="stylesheet" href="css/header.css">
        <link rel="stylesheet" href="css/btn.css">
        <link rel="stylesheet" href="css/login.css">
        <link rel="stylesheet" href="css/livro.css">
        <link rel="stylesheet" href="css/section.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
    </head>

    <body>
        <?php
            include_once('cabecario.php');
            include_once('login.php');
        ?>
        <section class="section product-detail">

            <div class="details container">
                <div class="left image-container">
                    <div class="main">
                        <img src="./imageTitle/<?php echo $linha['foto'];?>" id="zoom" alt=""/>
                    </div>
                </div>

                <div class="right">
                    <div class="url">
                        <div class="pname">
                            <h1 class="title"><?php echo $linha['titulo_nome'] ?></h1>
                        </div>
                        <?php
                            $titulo = $linha['codigo_titulo'];
                            echo"<a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                <i class='fa-solid fa-heart'></i>  
                            </a>";
                        ?>                  
                                     
                    </div>
                         
            
                    <div class="price">
                        <div class="last-price">
                            <h2><?php echo "R$ " . number_format($linha['valor'], 2, ',', '.');?></h2>
                        </div>
                    </div>  
                    
                    <h2><?php echo $linha['status'] ?></h2>

                    <div class="btn-box">

                        <?php 
                            $num = 18996809827;

                            $number = preg_replace("/[^0-9]/", "", $num);
                            $mensagem = "Olá! Estou interessado nesse livro : %0Ahttp://localhost/livraria/livro.php?id=".$linha['codigo_titulo']."%0A, Nome : ".$linha['titulo_nome']."%0A, Descrição:%20".$linha['descricao']."%0A, No valor:%20R$%20".number_format($linha['valor'], 2, ',', '.').".";
                        ?> 
                        <a class="btn" href="https://wa.me/55<?php echo $number;?>?text=<?php echo $mensagem;?>" 
                            title="Comprar pelo WhatsApp"><span>Negociar</span>
                            <i class="fa-brands fa-square-whatsapp"></i>
                        </a>
									
                                     
                    </div>
           
                </div>
            </div>
        </section>

        <section class="info-book" id="info-book">
            <h1 class="heading">
                <span>Descrição</span></h1>
            <div class="box-container">
                <div class="box">
                    <table class="src__SpecsCell-sc-70o4ee-5 gYhGqJ">
                        <tbody>
                            <tr class="spec-drawer__View-sc-jcvy3q-4 eHkstE">
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">
                                    Código
                                </td>
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">
                                    <?php echo $linha['codigo_titulo'] ?>
                                </td>
                            </tr>                           
                            <tr class="spec-drawer__View-sc-jcvy3q-4 eHkstE">
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">
                                    Edição
                                </td>
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">
                                    Impresso
                                </td>
                            </tr>
                            <tr class="spec-drawer__View-sc-jcvy3q-4 eHkstE">
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">
                                    Editora
                                </td>
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">
                                <?php echo $linha['editora_nome'] ?>
                                </td>
                            </tr>
                            <tr class="spec-drawer__View-sc-jcvy3q-4 eHkstE">
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">
                                    Número de páginas
                                </td>
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">
                                <?php echo $linha['qntdd_pag'] ?>
                                </td>
                            </tr>
                            <tr class="spec-drawer__View-sc-jcvy3q-4 eHkstE">
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">Autor</td>
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">Lauren Kate</td>
                            </tr>
                            <tr class="spec-drawer__View-sc-jcvy3q-4 eHkstE">
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">Data de Publicação</td>
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">28/02/2011</td>
                            </tr>
                            <tr class="spec-drawer__View-sc-jcvy3q-4 eHkstE">
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd">Categoria</td>
                                <td class="spec-drawer__Text-sc-jcvy3q-5 fMwSYd"><?php echo $linha['categoria_nome'] ?></td>
                            </tr>                                           
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
        
        <section class="info-book" id="info-book">

            <h1 class="heading">
                <span>Sinopse do Livro</span>
            </h1>

            <div class="box-container">
                <p>
                    <?php echo $linha['descricao'] ?>
                </p>

            </div>
        </section>
    </div>
</div>

</section>

<section class="comments">

    <?php
        
        include_once('conexao.php');
     
        
        if(isset($_SESSION['tipo_acesso'])){
            $tipo = $_SESSION['tipo_acesso'];
            $cod = $_SESSION['idusuario'];

            $query = "SELECT *
            FROM titulo, comentario, usuario
            WHERE comentario.codigo_titulo_codigo = titulo.codigo_titulo
            AND comentario.codigo_usuario_codigo = usuario.codigo_usuario
            AND codigo_usuario = $cod
            AND tipo = 'usuario'
            ORDER BY codigo_comentario";                     
            $row = mysqli_query($conn, $query);

            if(mysqli_num_rows($row) > 0){

                echo "<h1 class='heading'>
                        <span>Meus Comentários</span>
                    </h1>";
                while($res = mysqli_fetch_assoc($row)){
                    $codigo = $res['codigo_usuario_codigo'];
                    $coment = $res['codigo_comentario'];
                    $titulo = $res['codigo_titulo'];
    ?>


                    <div class="content-comment">
                        <div class="card-comment">
                            <?php echo $res['comentario']?>                   
                        </div>
                        <div class="info-card">
                            <img src="imageTitle/<?php echo $_SESSION['foto'];?>" alt="Imagem" width="80px" heigth="90px">
                            <h1><?php echo $res['usuario_nome']?> (Eu)</h1>
                        </div>
                        <script src="js/funcoes.js"></script>

                        <?php 
                        $opcao = 1;
                        echo"<a href='editar_comentario.php?id=$titulo&coment=$coment' title='Alterar'>
                        <i class='fa fa-edit fa-2x'></i>
                    </a>";
                    echo"<a href='#' onclick='confirmacaoDescomentar($titulo, $opcao, $coment)' title='Excluir'><i class='fa fa-trash fa-2x'></i></a>";
                          
            
                        ?>
                    </div>
            <?php
                }

                $query = "SELECT *
                FROM titulo, comentario, usuario
                WHERE comentario.codigo_titulo_codigo = titulo.codigo_titulo
                AND comentario.codigo_usuario_codigo = usuario.codigo_usuario";                     
                $row = mysqli_query($conn, $query);

                echo "<h1 class='heading'>
                <span>Todos os Comentarios</span>
            </h1>";
    
                    while($res = mysqli_fetch_assoc($row)){
                        $codigo = $res['codigo_usuario_codigo'];
                        $coment = $res['comentario'];
                ?>


                        <div class="content-comment">
                            <div class="card-comment">
                                <?php echo $coment ?>                   
                            </div>
                            <div class="info-card">
                                <img src="imageTitle/<?php echo $res['foto_user'];?>" alt="Imagem" width="80px" heigth="90px">
                                <h1>Nome do Leitor : <?php echo $res['usuario_nome']?></h1>
                            </div>
                        </div>
                <?php
                    }
            } 
        }      
         else{
    
            $query = "SELECT *
            FROM titulo, comentario, usuario
            WHERE comentario.codigo_titulo_codigo = titulo.codigo_titulo
            AND comentario.codigo_usuario_codigo = usuario.codigo_usuario";                     
            $row = mysqli_query($conn, $query);

            echo "<h1 class='heading'>
                <span>Todos os Comentarios</span>
            </h1>";
    

                while($res = mysqli_fetch_assoc($row)){
                    $codigo = $res['codigo_usuario_codigo'];
                    $coment = $res['comentario'];
            ?>

                    <div class="content-comment">
                        <div class="card-comment">
                            <?php echo $coment ?>                   
                        </div>
                        <div class="info-card">
                            <img src="imageTitle/<?php echo $res['foto_user'];?>" alt="Imagem" width="80px" heigth="90px">
                            <h1>Nome do Leitor : <?php echo $res['usuario_nome']?></h1>
                        </div>
                    </div>
            <?php
                
                }
            }
        
            ?>



            <button class="btn"> 
                <a href="comentar.php?id=<?php echo $_GET['id'];?>">Comentar</a>
            </button>

   

</section>

<section class="featured1" id="featured1">
    <h1 class="heading">
        <span>Livros Relacionados</span>
    </h1>

    <div class="swiper featured-slider">

                <div class="swiper-wrapper">
                    <?php $codigo = $linha['codigo_categoria'];
                        $query = "SELECT * 
                        FROM titulo, categoria
                        WHERE categoria_codigo = '$codigo'                      
                        AND codigo_categoria = '$codigo'";
                        $row = mysqli_query($conn, $query);
                            
                            while($dados = mysqli_fetch_assoc($row)){
                                
                        ?>
                    <div class="swiper-slide box">
                        <div class="icons">

                        <?php

                        echo "
<a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                                            <i class='fa-solid fa-heart'></i>  
                                                        </a>

                                                        <a href='livro.php?id=$titulo' class='fas fa-eye'></a>";
                        ?>

                        </div>
                        
                        <div class="image">
                            <img src="imageTitle/<?php echo $dados['foto'];?>" alt="Imagem">
                        </div>

                        <div class="content">
                            <h3><?php echo $dados['titulo_nome'] ?></h3>
                            <div class="price">
                                <h1>R$<?php echo number_format($dados['valor'], 2, ',', '.')?></h1>
                            </div>                            
                        </div>
                    </div>
                    <?php
                            }
                    ?>
           
         
                    
                </div>
  <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </section>
    <?php
        include_once('rodape.php');
    ?>

    
</body>
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>
    <script src="js/script.js"></script>
    <script src="js/funcoes.js"></script>

</html>