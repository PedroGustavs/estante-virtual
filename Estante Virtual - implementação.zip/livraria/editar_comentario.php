<?php
    session_start();
    include_once('sessao.php');
    include_once('conexao.php');

    $exibirTipodeAcesso = $_SESSION['tipo_acesso'];
 
    if($exibirTipodeAcesso != "usuario"){
        header("location:dashboard.php");
    }
 
    $id=$_GET['id'];
    

    if (isset($id)) {
        if(isset($_GET['coment'])){

            $coment = $_GET['coment'];  
  
            $cod = $_SESSION['idusuario'];

            
            $query = "SELECT *
            FROM comentario, titulo, usuario
            WHERE codigo_titulo_codigo = $id
            AND codigo_usuario_codigo = $cod
            AND codigo_comentario = $coment
            ORDER BY codigo_comentario";
            $dados = mysqli_query($conn, $query);
            $linha = mysqli_fetch_assoc($dados);
            $comentario = $linha['comentario'];
        }
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Editar Comentario</title>
        <link rel="stylesheet" href="css/comentar.css">
        <link rel="stylesheet" href="css/button.css">
    </head>
    <body>
        <div class="comments">
            <div class="content">

           
            <?php
                echo "<form action='' method='post' class='form-cont'>
                    <h1>Editar Comentário</h1>

                    <div class='input-box'>
                        <textarea name='message' id='message' cols='30' rows='10'>$comentario</textarea>
                    </div>

                    <div class='login-button'>
                        <input type='submit'  name='alterar' class='btn btn-primary btn-block mt-3' id='btn'
                        value='Comentar'>
                    </div>

                </form>
                
                ";
            ?>
        </div> </div>
    </body>
</html>

<?php 
    if (isset($_POST['alterar'])) {
        if(!empty($_POST) && (empty($_POST['message']))){
            echo "<script type='text/javascript'>alert('Preencha todos os campos!');</script>";
            echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=editar_comentario.php?id=$id'>";        
        }
    
        else{
            $comentario = $_POST['message'];
          
            $query = "UPDATE comentario 
            SET comentario = '$comentario'           
            WHERE codigo_comentario = $coment";
            $result1 = mysqli_query($conn, $query);
           
            if ($result1) {
                echo "<script type='text/javascript'>OpcaoMensagens(2);</script>";
                echo "<meta HTTP-EQUIV='Refresh' CONTENT='0; URL=livro.php?id=$id'>";
            }
    
            else {
                echo "<script type='text/javascript'>OpcaoMensagens(5);</script>";
                echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=livro.php?id=$id'>";
            }

        }
            
    }

?>