<div class="login-form-container">

<div id="close-login-btn" class="fas fa-times"></div>

<form action="autenticador.php" method="post">
    <h3>Login</h3>
    <span>Email</span>
    <input
        type="email"
        name="email"
        id="senha"
        class="box"
        placeholder="digite seu email">
    <span>Senha</span>
    <input
        type="password"
        name="senha"
        id="senha"
        class="box"
        placeholder="digite sua senha">

    <input type="submit" value="Entrar" class="btn">

    <input
        type="button"
        name="cancelar"
        class="btn btn-primary btn-block mt-3"
        id="btn"
        value="Cadastrar"
            onclick="window.location.href='cadastrar_usuario.php'">
     
</form>
</div>
