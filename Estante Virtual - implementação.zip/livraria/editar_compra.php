<?php
    session_start();
    include_once('sessao.php');
    include_once('conexao.php');

    $exibirTipodeAcesso = $_SESSION['tipo_acesso'];
 
    if($exibirTipodeAcesso != "administrador"){
        header("location:dashboard.php");
        echo "<script type='text/javascript'>alert('Apenas o Administrador possui acesso a essa área!');</script>";
    }
 
    $id=$_GET['id'];

    if (isset($id)) {

        $query = "SELECT * 
        FROM compra, itemcompra, titulo, usuario
        WHERE codigo_compra_codigo = codigo_compra
        AND codigo_usuario_codigo = codigo_usuario
        AND codigo_titulo_codigo = codigo_titulo
        AND codigo_compra = $id
        ORDER BY codigo_compra";
        $dados = mysqli_query($conn, $query);
        $linha = mysqli_fetch_assoc($dados);
    }
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Editar Titulo</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="css/button.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>
        <div class="container">
            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">
                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="gerenciar_compra.php">Compra</a>
                        </span>
                        <span>
                            >
                            <a href="editar_compra.php">Editar Compra</a>
                        </span>
                    </span>
                </div>

                <div class="recent-users">
                <div class="form form2">
                    <form action="#" method="post">
                        
                        <h2 class="crud">Alterar Compra</h2>

                        <h1>Dados da Compra</h1>

                        <div class="input-group grid1">

                    
                                <div class="input-box">
                                    <label for="fornecedor" class="form-label">Fornecedor</label>
                                    <select
                                        name="fornecedor"
                                        id="fornecedor"
                                        class="form-control">
                                        <option value="<?php echo $linha['codigo_fornecedor'];?>" selected="selected">Selecione o fornecedor</option>
                                        <?php
                                        $query = "SELECT * FROM fornecedor ORDER BY codigo_fornecedor";
                                        $resultado = mysqli_query($conn, $query);
                                        while ($tabela = mysqli_fetch_assoc($resultado)) {
                                            if ($linha['codigo_fornecedor_codigo'] == $tabela['codigo_fornecedor']) {
                                    ?>
                                    <option value="<?php echo $tabela['codigo_fornecedor'];?>" selected="selected"><?php echo $tabela['fornecedor_nome'];?></option>
                                <?php
                                            }

                                            else {
                                    ?>

                                    <option value="<?php echo $tabela['codigo_fornecedor'];?>"><?php echo $tabela['fornecedor_nome'];?></option>
                                    <?php
                                            }
                                        }

                                    ?>
                                    </select>
                                </div>
                                
                                <div class="input-box">
                                    <label for="titulo" class="form-label">Título</label>
                                    <select
                                        name="titulo"
                                        id="titulo"
                                        class="form-control">
                                        <option value="" selected="selected">Selecione o título</option>
                                        <?php
                                        $query = "SELECT * FROM titulo ORDER BY codigo_titulo";
                                        $resultado = mysqli_query($conn, $query);
                                        while ($tabela = mysqli_fetch_assoc($resultado)) {
                                            if ($linha['codigo_titulo_codigo'] == $tabela['codigo_titulo']) {
                                    ?>
                                    <option value="<?php echo $tabela['codigo_titulo'];?>" selected="selected"><?php echo $tabela['titulo_nome'];?></option>
                                    <?php
                                            }

                                            else {
                                    ?>

                                    <option value="<?php echo $tabela['codigo_titulo'];?>"><?php echo $tabela['titulo_nome'];?></option>
                                    <?php
                                            }
                                        }

                                    ?>
                                    </select>
                                </div>
                                
                                <div class="input-box">
                                    <label for="data" class="form-label">Data da Venda</label>
                                    <input type="date" name="data" id="data"
                                     placeholder="informe o data da venda" value="<?php echo $linha['data']?>">
                                </div>

                                <div class="input-box">
                                    <label for="preco" class="form-label">Preço</label>
                                    <input type="number" name="preco" id="preco" 
                                    placeholder="informe o preço da venda" value="<?php echo $linha['preco']?>">
                                </div>

                                
                        </div>

                        <div class="login-button">
                            <input type="button" name="cancelar" class="btn btn-primary btn-block mt-3" id="btn"
                                value="Cancelar" onclick="window.location.href='gerenciar_compra.php'">
                            <input type="submit" name="alterar" class="btn btn-primary btn-block mt-3" id="btn"
                                value="Alterar">
                        </div>

                    </form>
                </div>
    

                </div>

             
            </main>
            <?php
            include_once('right_user.php');
            ?>
        </div>

    </body>

    <script src="js/funcoes.js"></script>

</html>
<?php 
    if (isset($_POST['alterar'])) {
        if(!empty($_POST) && (empty($_POST['fornecedor'])) || empty($_POST['data']) 
        || empty($_POST['preco']) || empty($_POST['titulo'])){
            echo "<script type='text/javascript'>alert('Preencha todos os campos!');</script>";
            echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=editar_venda.php?id=$id'>";        
        }
    
        else{

            $fornecedor = $_POST['fornecedor'];
            $titulo = $_POST['titulo'];
            $preco = $_POST['preco'];
            $codT = $linha['codigo_titulo'];

            $query = "UPDATE titulo 
            SET status ='Indisponivel'              
            WHERE codigo_titulo = $codT";
            $result1 = mysqli_query($conn, $query);
            var_dump($result1);

            if($preco <= 0){
                echo "<script type='text/javascript'>alert('O preço deve ser maior que zero!');</script>";
                echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=editar_venda.php?id=$id'>";
            }
            else{
                    $data = $_POST['data'];
                    $dataBrasil = implode('-', array_reverse(explode('/', "$data")));
                
                    $query = "UPDATE compra 
                    SET codigo_fornecedor_codigo = '$fornecedor', 
                    data = '$dataBrasil'                
                    WHERE codigo_compra = $id";
                    $result1 = mysqli_query($conn, $query);
                    var_dump($result1);
                    
                    $query1 = "UPDATE itemcompra
                    SET codigo_titulo_codigo ='$titulo',
                    codigo_compra_codigo ='$id',
                    preco = '$preco'             
                    WHERE codigo_compra_codigo = $id";
                    $result2 = mysqli_query($conn, $query1);

                    $status = "Disponivel";
                    $query = "UPDATE titulo 
                    SET titulo.status = '$status' 
                    WHERE codigo_titulo = $titulo";
                    $resultado3 = mysqli_query($conn, $query);

                    if ($result1 && $result2) {
                        echo "<script type='text/javascript'>OpcaoMensagens(2);</script>";
                        echo '<meta HTTP-EQUIV="Refresh" CONTENT="0; URL=gerenciar_compra.php">';
                    }
            
                    else {
                        echo "<script type='text/javascript'>OpcaoMensagens(5);</script>";
                        echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=editar_compra.php?id=$id'>";
                    }

                }
            
    }
}

?>