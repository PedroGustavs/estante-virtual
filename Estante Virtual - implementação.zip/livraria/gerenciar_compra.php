<?php
  session_start();
  include_once('conexao.php');
  include_once('sessao.php');//verifica se tem sessão e se está tudo ok!
  $exibirTipodeAcesso = $_SESSION['tipo_acesso'];//recebe o tipo de acesso
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="css/button.css">
        <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>
    
    <body>
        <div class="container">
            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">
                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="gerenciar_compra.php">Compras</a>
                        </span>
                    </span>
                </div>

                <div class="recent-users">
                    <h2 class="crud">Compra</h2>
                    <?php 
                    if ($exibirTipodeAcesso == "administrador") {
                ?>

                    <table>
                        <thead>
                            <tr>
                                <th>Codigo</th>
                                <th>Titulo</th>
                                <th>Nome do Livro</th>
                                <th>Status</th>
                                <th>Fornecedor</th>
                                <th>Usuário</th>
                                <th>Data</th>
                                <th>Preço</th>
                                <th>Ações</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                                $query = "SELECT * 
                                FROM compra, itemcompra, fornecedor, titulo, usuario
                                WHERE compra.codigo_fornecedor_codigo = fornecedor.codigo_fornecedor
                                AND compra.codigo_usuario_codigo = usuario.codigo_usuario
                                AND codigo_compra_codigo = codigo_compra
                                AND itemcompra.codigo_titulo_codigo = titulo.codigo_titulo
                                ORDER BY codigo_compra";
                                $row = mysqli_query($conn, $query);
                                while($dados = mysqli_fetch_assoc($row)){
                            ?>

                            <tr>
                                <td><?php echo $dados['codigo_compra']; ?></td>
                                <td><img
                                    src="imageTitle/<?php echo $dados['foto'];?>"
                                    alt="Imagem"
                                    width="80px"
                                    heigth="90px">
                                </td>
                                <td><?php echo $dados['titulo_nome'];?></td>
                                <td><?php echo $dados['status'];?></td>
                                <td><?php echo $dados['fornecedor_nome'];?></td>
                                <td><?php echo $dados['usuario_nome'];?></td>
                                <td><?php echo $dados['data'];?></td>
                                <td><?php echo $dados['valor'];?></td>
                                <td>
                                    <div class="td">
                                        <?php 
                                        echo"<a href='editar_compra.php?id=".$dados['codigo_compra']."' title='Alterar'><i class='fa fa-edit fa-2x'></i></a>";
                                        $id = $dados['codigo_compra'];
                                        echo"<a href='#' onclick='ConfirmarExclusaoCompra($id)' title='Excluir'><i class='fa fa-trash fa-2x'></i></a>";
                                    ?>
                                    </div>

                                </td>
                            </tr>

                            <?php
                                }
                            ?>
                        </tbody>

                    </table>
                    <div class="btn-box">
                        <input
                            type="button"
                            name="Cadastrar"
                            class="btn btn-primary pull-center"
                            value="Cadastrar Compra"
                            id="btn"
                            onclick="window.location.href='cadastrar_compra.php'">

                    </div>

                <?php
                }  else {
                ?>

                    <div class="sales">
                        <a href="#">
                            <span class="material-symbols-sharp">
                                shopping_bag
                            </span>

                            <h3 class="h3">Minhas Compras</h3>
                            <?php //filtrar por status, pagamento pendente, preparando,a caminho, finalizado, avaliar ?>
                        </a>

                    </div>

                    <div class="sales">
                        <a href="#">

                            <span class="material-symbols-sharp">
                                favorite
                            </span>

                            <?php //filtrar por preço, status(disponivel ou indisponivel), categoria, autor, editora?>

                            <h3 class="h3">Livros Favoritados</h3>
                        </a>
                    </div>

                    <div class="sales">
                        <a href="#">

                            <span class="material-symbols-sharp">
                                comment
                            </span>

                            <h3 class="h3">Meus Comentários</h3>
                        </a>
                    </div>

                    <div class="sales">
                        <a href="#">
                            <span class="material-symbols-sharp">
                                shopping_cart
                            </span>
                            <h3 class="h3">Carrinho de Compras</h3>
                        </a>
                    </div>

                    <div class="sales">
                        <a href="#">
                            <span class="material-symbols-sharp">
                                settings
                            </span>
                            <h3 class="h3">Configurações</h3>
                        </a>
                    </div>

                    <div class="sales">
                        <a href="#">
                            <span class="material-symbols-sharp">
                                schedule
                            </span>

                            <h3 class="h3">Vistos Recentemente</h3>
                        </a>
                    </div>

                    <?php
                    }
                ?>

                </div>

            </main>

        <?php
            if($exibirTipodeAcesso == "administrador"){
                include_once('right_user.php');
            }  
            
            else{
                ?>

            <div class="user-photo">
                <img
                    src="imageTitle/<?php echo $_SESSION['foto'];?>"
                    alt="Imagem"
                    width="80px"
                    heigth="90px">
                <h2><?php echo $_SESSION['nome']?></h2>
            </div>
            <?php
            }
            ?>
        </div>
    </body>
    <script src="js/funcoes.js"></script>

</html>

</body>

</html>