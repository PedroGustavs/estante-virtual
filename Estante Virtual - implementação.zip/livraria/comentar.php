<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Comentar</title>
        <link rel="stylesheet" href="css/comentar.css">
        <link rel="stylesheet" href="css/button.css">
    </head>
    <body>
        <div class="comments">
            <div class="content">

           
            <?php
                $id = $_GET['id'];
                echo " <form action='verificar_comentario.php?id=$id' method='post' class='form-cont'>
                    <h1>Efetuar Comentário</h1>

                    <div class='input-box'>
                        <textarea name='comment' id='comment' cols='30' rows='10'></textarea>
                    </div>

                    <div class='login-button'>
                        <input type='submit'  name='comentar' class='btn btn-primary btn-block mt-3' id='btn'
                        value='Comentar'>
                    </div>

                
                </form>
                
                ";
            ?>
        </div> </div>
    </body>
</html>