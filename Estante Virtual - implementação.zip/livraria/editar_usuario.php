<?php
  session_start();
  include_once('sessao.php');//verifica se tem sessão e se está tudo ok!
  //chama a conecao com banco de dados
  include_once('conexao.php');
    $codigo = $_SESSION['idusuario'];//recebe o tipo de acesso
    $query = "SELECT * FROM usuario WHERE codigo_usuario = $codigo";
    $result = mysqli_query($conn, $query);
    $row = mysqli_fetch_assoc($result);
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Editar Usuario</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="css/button.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>
        <div class="container">
            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">

                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="configuracao.php">Configuração</a>
                        </span>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="conta_seguranca.php">Conta e Segurança</a>
                        </span>
                        <span>
                            >
                        </span>
                        <span>
                            <a href="meu_perfil.php">Meu Perfil</a>
                        </span>
                    </span>
                </div>

                <div class="recent-users">
                    <div class="form form2">
                        <form action="#" method="post" enctype="multipart/form-data">
                            <h1 class="crud">Alterar Fornecedor</h1>

                            <h1>Dados Pessoais</h1>

                            <div class="input-group grid1">

                                <div class="input-box">
                                    <label for="name" class="form-label">Nome</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        id="name"
                                        name="name"
                                        placeholder="Informe o nome do fornecedor"
                                        value="<?php echo $_SESSION['nome']?>">
                                </div>

                                <div class="input-box">
                                    <label for="email" class="form-label">Email</label>
                                    <input
                                        type="email"
                                        class="form-control"
                                        name="email"
                                        id="email"
                                        placeholder="Informe o email do fornecedor"
                                        value="<?php echo $_SESSION['email']?>">
                                </div>

                                <div class="input-box">
                                    <label for="telefone" class="form-label">Telefone</label>
                                    <input
                                        type="tel"
                                        class="form-control"
                                        name="telefone"
                                        id="telefone"
                                        placeholder="Informe o telefone do fornecedor"
                                        value="<?php echo $_SESSION['telefone']?>">
                                </div>
                            </div>

                            <h1>Endereço</h1>
                            <div class="input-group grid1">

                                <div class="input-box">
                                    <label for="rua" class="form-label">Rua</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        name="rua"
                                        id="rua"
                                        placeholder="Informe a rua do fornecedor"
                                        value="<?php echo $_SESSION['rua']?>">
                                </div>

                                <div class="input-box">
                                    <label for="numero" class="form-label">Número</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        name="numero"
                                        id="numero"
                                        placeholder="Informe o numero da rua do fornecedor"
                                        value="<?php echo $_SESSION['numero']?>">
                                </div>

                                <div class="input-box">
                                    <label for="bairro" class="form-label">Bairro</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        name="bairro"
                                        id="bairro"
                                        placeholder="Informe o bairro do fornecedor"
                                        value="<?php echo $_SESSION['bairro']?>">
                                </div>

                                <div class="input-box">
                                    <label for="cep" class="form-label">CEP</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        name="cep"
                                        id="cep"
                                        placeholder="Informe o cep do fornecedor"
                                        value="<?php echo $_SESSION['cep']?>">
                                </div>
                                <div class="input-box">
                                    <label for="cidade" class="form-label">Cidade</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        name="cidade"
                                        id="cidade"
                                        placeholder="Informe a cidade do fornecedor"
                                        value="<?php echo $_SESSION['cidade']?>">
                                </div>
                                <div class="input-box">
                                    <label for="estado" class="form-label">CEP</label>
                                    <input
                                        type="text"
                                        class="form-control"
                                        name="estado"
                                        id="estado"
                                        placeholder="Informe o estado do fornecedor"
                                        value="<?php echo $_SESSION['estado']?>">
                                </div>

                                <div class="input-box">
                                    <label for="foto_arquivo" class="form-label">Imagem</label>
                                    <input
                                        type="file"
                                        class="form-control"
                                        name="foto_arquivo"
                                        id="foto_arquivo"
                                        onchange="previewImagem();">
                                </div>
                            </div>

                            <div class="form-group col-sm-12" style="text-align:center;">
                            <h1>Imagem Usuário</h1>
                                                
                            <img src="imageTitle/<?php echo $_SESSION['foto'];?>" name="visualizar" id="visualizar" width="200px" height="200px">
                        
                            
                           
                            </div>
                            <div class="login-button">
                                <input
                                    type="button"
                                    name="cancelar"
                                    class="btn btn-primary btn-block mt-3"
                                    id="btn"
                                    value="Cancelar"
                                    onclick="window.location.href='listar_fornecedor.php'">
                                <input
                                    type="submit"
                                    name="alterar"
                                    class="btn btn-primary btn-block mt-3"
                                    id="btn"
                                    value="Alterar">
                            </div>

                        </form>
                    </div>

                </div>

            </main>

            <?php
            include_once('right_user.php');
            ?>
        </div>

    </body>

    <script>
        function previewImagem() {
            var imagem = document
                .querySelector('input[name=foto_arquivo]')
                .files[0];
            var preview = document.querySelector('img[name=visualizar]');
            var reader = new FileReader();

            reader.onloadend = function () {
                preview.src = reader.result;
            }

            if (imagem) {
                reader.readAsDataURL(imagem);
            } else {
                preview.src = "";
            }
        }
    </script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script
        src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.15/jquery.mask.min.js"></script>
    <script>
        $("#telefone").mask("(99) 9999-9999");
        $("#cep").mask("99999-999");
    </script>

    <script src="js/estado.js"></script>

    <script
        src="https://code.jquery.com/jquery-3.4.1.min.js"
        integrity="sha256-CSXorXvZcTkaix6Yvo6HppcZGetbYMGWSFlBw8HfCJo="
        crossorigin="anonymous"></script>
    <!-- Adicionando Javascript -->
    <script>
        $(document).ready(function () {
            function limpa_formulário_cep() {
                $("#cidade").val("");
                $("#estado").val("");
            }

            $("#cep").blur(function () {
                var cep = $(this)
                    .val()
                    .replace(/\D/g, '');
                if (cep != "") {
                    var validacep = /^[0-9]{8}$/;
                    if (validacep.test(cep)) {

                        $("#cidade").val("...");
                        $("#estado").val("...");

                        $.getJSON(
                            "https://viacep.com.br/ws/" + cep + "/json/?callback=?",
                            function (dados) {

                                if (!("erro" in dados)) {

                                    $("#cidade").val(dados.localidade);
                                    $("#estado").val(dados.uf);
                                } else {
                                    //CEP pesquisado não foi encontrado.
                                    limpa_formulário_cep();
                                    alert("CEP não encontrado.");
                                }
                            } //end if.
                        );
                    } else {
                        //cep é inválido.
                        limpa_formulário_cep();
                        alert("Formato de CEP inválido.");
                    }
                } else {
                    //cep sem valor, limpa formulário.
                    limpa_formulário_cep();
                }
            });
        });
    </script>
    <script src="js/funcoes.js"></script>

</html>

<?php
  if(isset($_POST['alterar'])){
        if (!empty($_POST) && (empty($_POST['name']) || empty($_POST['email']) || empty($_POST['telefone']) || empty($_POST['cidade'])
            || empty($_POST['estado']) || empty($_POST['rua']) || empty($_POST['numero']) || empty($_POST['cep']) || empty($_POST['bairro']))) {
            echo "<script type='text/javascript'>alert('Preencha todos os campos!');</script>";
            echo "<meta HTTP-EQUIV='refresh' CONTENT='0; URL=editar_usuario.php'>";
        }
        else{

            if (isset($_FILES['foto_arquivo'])) {


                echo "teem ft";
                $foto = $_SESSION['foto'];
                echo unlink("imageTitle/" . $foto);//APAGA A IMAGEM NO DIRETÓRIO
                
                if (isset($_FILES['foto']['name']) && $_FILES['foto']['error'] == 0) {
                    $arquivo_tmp = $_FILES['foto']['tmp_name'];
                    $nome = $_FILES['foto']['name'];//images.png
                    $extensao = strrchr($nome, '.');//png
                    $extensao = strtolower($extensao);
                    if (strstr('.svg;.pdf;.png;.jpg;.jpeg;.gif', $extensao)) {
                        $novoNome = md5(microtime()) . '.' . $extensao;
                        $destino = 'imageTitle/' . $nome;
                        if (@move_uploaded_file($arquivo_tmp, $destino)) {
                            //echo "Arquivo salvo com sucesso";
                        } else {
                            echo "Erro ao salvar o arquivo";
                        }           
                    } else {
                        echo "Formato de arquivo invalido!";
                    }            
               
                $img_user  = $nome; 
                $email = $_POST['email'];
            $name = $_POST['name'];
            $telefone = $_POST['telefone'];
            $estado = $_POST['estado'];
            $cidade = $_POST['cidade'];
            $cep = $_POST['cep'];
            $bairro = $_POST['bairro'];
            $numero = $_POST['numero'];
            $rua = $_POST['rua'];

            $result = "UPDATE usuario
            SET usuario_nome = '$name',
            telefone = '$telefone',
            estado = '$estado',
            numero = '$numero',          
            email = '$email',
            rua = '$rua',
            numero = '$numero',
            cep = '$cep',
            cidade = '$cidade',
            foto_user = '$img_user',
            bairro = '$bairro',      
            WHERE codigo_usuario = $codigo"; 
            var_dump($result);
            $linhaunica = mysqli_query($conn, $result);
            }
            
        }
    }
}
         
        
    
?>