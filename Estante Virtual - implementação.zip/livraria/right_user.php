<div class="right">
            <div class="top">
                <button id="menu-btn">
                    <i class="fa-solid fa-bars"></i>
                </button>
                              
            </div>

            <div class="user-photo">
            <img
                                        src="imageTitle/<?php echo $_SESSION['foto'];?>"
                                        alt="Imagem"
                                        width="80px"
                                        heigth="90px">
                <h2><?php echo $_SESSION['nome']?></h2> 
            </div>
            <div class="recent-updates">
                <h2>Alterações recentes</h2>
                <div class="updates">
                    <div class="update">
                        <div class="profile-photo">
                            <img src="image/catra.jpg" alt="">
                        </div>
                        <div class="message">
                            <p><b>Arthur Storini</b> recebeu o livro dele</p>
                        <small class="text-muted">2 Minutos Atras</small>
                        </div>
                    </div>
                    <div class="update">
                        <div class="profile-photo">
                            <img src="image/catra.jpg" alt="">
                        </div>
                        <div class="message">
                            <p><b>Arthur Storini</b> recebeu o livro dele</p>
                        <small class="text-muted">2 Minutos Atras</small>
                        </div>
                    </div>
                    <div class="update">
                        <div class="profile-photo">
                            <img src="image/catra.jpg" alt="">
                        </div>
                        <div class="message">
                            <p><b>Arthur Storini</b> recebeu o livro dele</p>
                        <small class="text-muted">2 Minutos Atras</small>
                        </div>
                    </div>
                    <div class="update">
                        <div class="profile-photo">
                            <img src="image/catra.jpg" alt="">
                        </div>
                        <div class="message">
                            <p><b>Arthur Storini</b> recebeu o livro dele</p>
                        <small class="text-muted">2 Minutos Atras</small>
                        </div>
                    </div>
                </div>
            </div>     
        </div>