
<?php

$id = $_GET['id'];

if($id > 0){
    include_once('conexao.php');

    session_start();

    if($_SESSION['tipo_acesso'] != "usuario"){
        echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=index.php'>";
    }

    $query = "SELECT *
    FROM usuario
    WHERE codigo_usuario = $id";
    $dados3 = mysqli_query($conn, $query);
    $dadosusuario = mysqli_fetch_assoc($dados3);
    $pedido = $dadosusuario['pedido'];

    if($pedido == "solicitado"){
        echo "<script type='text/javascript'>alert('Solicitaçao ja foi efetuada!');</script>";
        echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=configuracao.php'>";
    }
    else{

        $query = "UPDATE usuario
        SET pedido = 'solicitado' 
        WHERE codigo_usuario = $id";
        $dados = mysqli_query($conn, $query);
        var_dump($dados);
 
        if($dados){
            echo "<script type='text/javascript'>alert('Solicitacao efetuada com Sucesso!');</script>";
            echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=configuracao.php'>";
        }

        else{
            echo "<script>OpcaoMensagem(5)</script>";
            echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=configuracao.php'>";
        }

    }



}
else{
    echo "<meta HTTP-EQUIV='Refresh' CONTENT='0 URL=index.php'>";
}
?>
<script src="js/funcoes.js"></script>