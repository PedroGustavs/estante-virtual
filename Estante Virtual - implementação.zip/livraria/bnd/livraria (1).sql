-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 05-Dez-2022 às 14:45
-- Versão do servidor: 5.7.26-log
-- versão do PHP: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `livraria`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `autor`
--

CREATE TABLE `autor` (
  `codigo_autor` int(11) NOT NULL,
  `autor_nome` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `autor`
--

INSERT INTO `autor` (`codigo_autor`, `autor_nome`) VALUES
(1, 'Teresa Chavez'),
(2, 'Luiza Santos'),
(3, 'Arthur Santos'),
(4, 'Fernando Moreno'),
(5, 'Aurora Rodriges'),
(6, 'Lauren Kate'),
(8, 'Becca Fitzpatrick');

-- --------------------------------------------------------

--
-- Estrutura da tabela `autor_titulo`
--

CREATE TABLE `autor_titulo` (
  `codigo_autor_codigo` int(11) NOT NULL,
  `codigo_titulo_codigo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `autor_titulo`
--

INSERT INTO `autor_titulo` (`codigo_autor_codigo`, `codigo_titulo_codigo`) VALUES
(6, 13),
(8, 14),
(6, 15),
(2, 16),
(8, 17),
(2, 18),
(8, 20),
(8, 21),
(6, 22),
(3, 11);

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria`
--

CREATE TABLE `categoria` (
  `codigo_categoria` int(11) NOT NULL,
  `categoria_nome` varchar(450) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `categoria`
--

INSERT INTO `categoria` (`codigo_categoria`, `categoria_nome`) VALUES
(1, 'Romance'),
(2, 'Terror'),
(3, 'Ficçao cientifica'),
(4, 'Misterio'),
(5, 'Aventura'),
(6, 'Infantil');

-- --------------------------------------------------------

--
-- Estrutura da tabela `comentario`
--

CREATE TABLE `comentario` (
  `codigo_comentario` int(11) NOT NULL,
  `codigo_titulo_codigo` int(11) NOT NULL,
  `codigo_usuario_codigo` int(11) NOT NULL,
  `comentario` varchar(2000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `comentario`
--

INSERT INTO `comentario` (`codigo_comentario`, `codigo_titulo_codigo`, `codigo_usuario_codigo`, `comentario`) VALUES
(8, 13, 16, 'eu adorei e amei'),
(9, 13, 16, 'foi mt bom'),
(10, 13, 16, 'pq ele morre\r\n');

-- --------------------------------------------------------

--
-- Estrutura da tabela `compra`
--

CREATE TABLE `compra` (
  `codigo_compra` int(11) NOT NULL,
  `codigo_usuario_codigo` int(11) NOT NULL,
  `codigo_fornecedor_codigo` int(11) NOT NULL,
  `data` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `compra`
--

INSERT INTO `compra` (`codigo_compra`, `codigo_usuario_codigo`, `codigo_fornecedor_codigo`, `data`) VALUES
(1, 15, 3, '2022-12-29'),
(2, 15, 6, '2022-12-05'),
(3, 15, 7, '2022-12-05'),
(4, 15, 7, '2022-12-05'),
(5, 15, 3, '2022-12-31');

-- --------------------------------------------------------

--
-- Estrutura da tabela `editora`
--

CREATE TABLE `editora` (
  `codigo_editora` int(11) NOT NULL,
  `editora_nome` varchar(40) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `telefone` char(20) DEFAULT NULL,
  `rua` varchar(45) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cep` varchar(15) DEFAULT NULL,
  `estado` char(2) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `editora`
--

INSERT INTO `editora` (`codigo_editora`, `editora_nome`, `email`, `telefone`, `rua`, `numero`, `bairro`, `cep`, `estado`, `cidade`) VALUES
(1, 'Intrinseca', 'pedro.gustavo@aluno.ifsp.edu.br', '(57) 6556-7756', 'MarquÃªs de SÃ£o Vicente', 65765, '567Itai7i', '19450-000', 'SP', 'CaiuÃ¡'),
(2, 'Ouro Preto', 'ouro@gmail.com', '(98) 7978-8978', 'MarquÃªs de SÃ£o Vicente', 38, 'Centro Passeio Corporate', '19450-000', 'SP', 'Caiuá'),
(3, 'Grupo editorial', 'grupoeditorial@gmail.com', '(41) 7756-5667', 'rua infeno ', 345, 'vila palmira', '80010-010', 'PR', 'Curitiba'),
(4, 'Darside Livros6', 'darkbooks@gmail.com', '(23) 7787-8656', 'rua dark', 345, 'vila palmira', '05042-000', 'SP', 'São Paulo'),
(5, 'Aleph', 'aleph@gmail.com', '(46) 3757-5676', 'Marquês de São Vicente', 345, 'vila palmira', '85851-000', 'PR', 'Foz do Iguaçu'),
(6, 'Editora Sextante', 'sextante@gmail.com', '(76) 5568-7878', 'Rua do Passeio', 67, 'Centro Passeio Corporate', '05042-000', 'SP', 'São Paulo');

-- --------------------------------------------------------

--
-- Estrutura da tabela `favoritado`
--

CREATE TABLE `favoritado` (
  `codigo_favoritado` int(11) NOT NULL,
  `codigo_titulo_codigo` int(11) NOT NULL,
  `codigo_usuario_codigo` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `favoritado`
--

INSERT INTO `favoritado` (`codigo_favoritado`, `codigo_titulo_codigo`, `codigo_usuario_codigo`) VALUES
(14, 11, 16),
(15, 22, 16),
(16, 13, 16);

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornecedor`
--

CREATE TABLE `fornecedor` (
  `codigo_fornecedor` int(11) NOT NULL,
  `estado` char(2) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `fornecedor_nome` varchar(40) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `telefone` char(20) DEFAULT NULL,
  `rua` varchar(45) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cep` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `fornecedor`
--

INSERT INTO `fornecedor` (`codigo_fornecedor`, `estado`, `cidade`, `fornecedor_nome`, `email`, `telefone`, `rua`, `numero`, `bairro`, `cep`) VALUES
(1, 'SP', 'Presidente EpitÃ¡cio', 'fernando algo', 'fernando1@gmail.com', '(98) 7978-8978', 'MarquÃªs de SÃ£o Vicente', 345, 'Centro Passeio Corporate', '19470-000'),
(2, 'SP', 'Caiuá', 'Evellyn 1', 'evellyn@gmail.com', '(56) 7667-5766', 'Marquês de São Vicente', 345, 'Itaim Bibi', '19450-000'),
(3, 'SP', 'Caiuá', 'Ines Brasil', 'ines@gmail.com', '(98) 7978-8978', 'Bandeira Paulista', 456, 'Centro Passeio Corporate', '19450-000'),
(5, 'SP', 'Presidente Epitácio', 'Matheus Serralvo', 'matheus@gmail.com', '(65) 6564-5665', 'Rua Tabapuã', 56, 'vila esperança', '19470-000'),
(6, 'SP', 'São Paulo', 'Elenistica', 'elenistica@gmail.com', '(54) 5343-5478', 'Rua Tabapuã', 99, 'vila palmira', '05042-000'),
(7, 'SP', 'São Paulo', 'Samira Close', 'samira@gmail.com', '(34) 5464-5453', 'rua paraiso', 81, 'centro matador', '05042-000'),
(8, 'SP', 'Presidente Epitácio', 'Luiza Santos', 'luiza@gmail.com', '(63) 5456-4665', 'Marquês de São Vicente', 345, 'vila palmira', '19470-000');

-- --------------------------------------------------------

--
-- Estrutura da tabela `itemcompra`
--

CREATE TABLE `itemcompra` (
  `codigo_item_compra` int(11) NOT NULL,
  `codigo_titulo_codigo` int(11) NOT NULL,
  `codigo_compra_codigo` int(11) NOT NULL,
  `preco` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `itemcompra`
--

INSERT INTO `itemcompra` (`codigo_item_compra`, `codigo_titulo_codigo`, `codigo_compra_codigo`, `preco`) VALUES
(1, 14, 1, 56),
(2, 15, 2, 45),
(3, 22, 3, 45),
(4, 15, 4, 56),
(5, 18, 5, 45);

-- --------------------------------------------------------

--
-- Estrutura da tabela `itemvenda`
--

CREATE TABLE `itemvenda` (
  `codigo_titulo_codigo` int(11) NOT NULL,
  `codigo_venda_codigo` int(11) NOT NULL,
  `preco` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `itemvenda`
--

INSERT INTO `itemvenda` (`codigo_titulo_codigo`, `codigo_venda_codigo`, `preco`) VALUES
(13, 1, 56),
(16, 2, 34);

-- --------------------------------------------------------

--
-- Estrutura da tabela `titulo`
--

CREATE TABLE `titulo` (
  `codigo_titulo` int(11) NOT NULL,
  `categoria_codigo` int(11) NOT NULL,
  `editora_codigo` int(11) NOT NULL,
  `titulo_nome` varchar(100) NOT NULL,
  `descricao` varchar(4500) DEFAULT NULL,
  `qntdd_pag` int(11) NOT NULL,
  `valor` double NOT NULL,
  `foto` text NOT NULL,
  `status` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `titulo`
--

INSERT INTO `titulo` (`codigo_titulo`, `categoria_codigo`, `editora_codigo`, `titulo_nome`, `descricao`, `qntdd_pag`, `valor`, `foto`, `status`) VALUES
(11, 3, 2, 'Shera', 'Nora Grey nÃ£o consegue se lembrar dos Ãºltimos cinco meses. Depois do choque inicial de acordar em um cemitÃ©rio e descobrir que ficou desaparecida por semanas, ela precisa retomar sua rotina, voltar Ã  escola, reencontrar a melhor amiga, Vee, e ainda aprender a conviver com o novo namorado da mÃ£e.', 456, 67, 'c0e4feded1f86cc71fb00d9978a0edd2..jpg', 'Indisponivel'),
(13, 1, 2, 'Extase', 'No quarto e Ãºltimo aguardado livro da sÃ©rie Fallen, Luce e Daniel estÃ£o juntos e parece que nada mais vai separÃ¡-los. O problema Ã© que o destino amaldiÃ§oado de uma mortal e de um anjo caÃ­do promete surpresas. O cÃ©u estÃ¡ escuro com asasâ€¦ Como a areia numa ampulheta, o tempo estÃ¡ se esgotando para Luce e Daniel.', 359, 56, 'ba1cb5e09ed77c35b473e0cf6f262db5..jpg', 'Disponivel'),
(14, 1, 1, 'Eu Estou Pensando em Acabar com Tudo', 'Jake dirige o carro em direÃ§Ã£o Ã  casa de seus pais, na fazenda. Ele leva consigo a sua nova namorada. Ela, apesar de gostar de Jake, acha muito cedo para conhecer sua famÃ­lia. AtÃ© porque existe o pensamento. O pensamento de acabar com tudo.\r\nDurante as horas de viagem entre a cidade e o interior, por estradas desertas cercadas por florestas e escuridÃ£o, as lembranÃ§as e as dÃºvidas lhes servirÃ£o como companhia. Mas hÃ¡ algo errado. Uma tensÃ£o que pode ser sentida no ar, nos movimentos e nas convicÃ§Ãµes.', 345, 67, 'c746dfc1795fd05689907758e36cf74d..jpg', 'Disponivel'),
(15, 1, 1, 'Fallen ', 'Caninos alongados vÃªm dominando o mercado editorial nos Ãºltimos anos. Mas segundo especialistas â€” entre eles o conceituado jornal britÃ¢nico The Observer â€”, asas e plumas prometem acabar com esse reinado. Anjos caÃ­dos sÃ£o a nova onda e comeÃ§am a tomar o lugar dos sugadores de sangue nas prateleiras e nas listas. Assim como seus pÃ¡lidos primos, esses seres celestiais sÃ£o visitantes sobrenaturais, donos de uma carga de adrenalina e sexualidade latente que promete arrebatar os leitores mais jovens. Fallen comprova a forÃ§a da nova tendÃªncia. Com uma trama que gira em torno do amor entre um anjo e uma adolescente, o livro de Lauren Kate foi lanÃ§ado no inÃ­cio de dezembro de 2009 e chegou Ã  lista do NY Times jÃ¡ no fim do mesmo mÃªs. Desde entÃ£o, mantÃ©m presenÃ§a constante na prestigiada tabela. E, a reboque, teve os direitos para o cinema comprados. A expectativa para o longa Ã© tanta, que vÃ¡rios fÃ£s da histÃ³ria postaram suas prÃ³prias versÃµes do trailer â€” e do elenco ideal â€” no Youtube. Lauren aposta no amor impossÃ­vel entre os protagonistas para tecer o inÃ­cio de uma saga com todos os ingredientes de um cult do gÃªnero. Em Fallen, acompanhamos a adolescente Luce, mandada para um reformatÃ³rio â€” apropriadamente batizado de Sword & Cross â€” apÃ³s a morte do namorado em um incÃªndio misterioso. Ela suspeita que estranhas sombras negras, que a atormentam desde a infÃ¢ncia, sÃ£o as verdadeiras responsÃ¡veis. Mas quem acreditaria nela? Na escola, ela encontra o etereamente belo Daniel Grigori, que desperta uma estranha sensaÃ§Ã£o de reconhecimento: Ãºnico ponto luminoso num lugar onde celulares sÃ£o proibidos e hÃ¡ cÃ¢meras de vigilÃ¢ncia por todos os cantos. Mas tanta luz hipnotiza a menina, atraÃ­da pelo rapaz como uma mariposa pela chama. Ele tenta se manter afastado de Luce, mas tambÃ©m nÃ£o consegue. E a verdade promete separÃ¡-los como tantas outras vezes â€” com a morte de Luce. Amantes destinados a se encontrar e se perder vida apÃ³s vida, sÃ©culo apÃ³s sÃ©culo. Excitante, sombrio e romÃ¢ntico Fallen Ã©, ao mesmo tempo, um thriller vigoroso e uma inesquecÃ­vel histÃ³ria de amor.', 345, 56, '0245399ae141dbc9390fe9503eac8fcb..jpeg', 'Disponivel'),
(16, 1, 1, 'Finale', 'Caninos alongados vÃªm dominando o mercado editorial nos Ãºltimos anos. Mas segundo especialistas â€” entre eles o conceituado jornal britÃ¢nico The Observer â€”, asas e plumas prometem acabar com esse reinado. Anjos caÃ­dos sÃ£o a nova onda e comeÃ§am a tomar o lugar dos sugadores de sangue nas prateleiras e nas listas. Assim como seus pÃ¡lidos primos, esses seres celestiais sÃ£o visitantes sobrenaturais, donos de uma carga de adrenalina e sexualidade latente que promete arrebatar os leitores mais jovens. Fallen comprova a forÃ§a da nova tendÃªncia. Com uma trama que gira em torno do amor entre um anjo e uma adolescente, o livro de Lauren Kate foi lanÃ§ado no inÃ­cio de dezembro de 2009 e chegou Ã  lista do NY Times jÃ¡ no fim do mesmo mÃªs. Desde entÃ£o, mantÃ©m presenÃ§a constante na prestigiada tabela. E, a reboque, teve os direitos para o cinema comprados. A expectativa para o longa Ã© tanta, que vÃ¡rios fÃ£s da histÃ³ria postaram suas prÃ³prias versÃµes do trailer â€” e do elenco ideal â€” no Youtube. Lauren aposta no amor impossÃ­vel entre os protagonistas para tecer o inÃ­cio de uma saga com todos os ingredientes de um cult do gÃªnero. Em Fallen, acompanhamos a adolescente Luce, mandada para um reformatÃ³rio â€” apropriadamente batizado de Sword & Cross â€” apÃ³s a morte do namorado em um incÃªndio misterioso. Ela suspeita que estranhas sombras negras, que a atormentam desde a infÃ¢ncia, sÃ£o as verdadeiras responsÃ¡veis. Mas quem acreditaria nela? Na escola, ela encontra o etereamente belo Daniel Grigori, que desperta uma estranha sensaÃ§Ã£o de reconhecimento: Ãºnico ponto luminoso num lugar onde celulares sÃ£o proibidos e hÃ¡ cÃ¢meras de vigilÃ¢ncia por todos os cantos. Mas tanta luz hipnotiza a menina, atraÃ­da pelo rapaz como uma mariposa pela chama. Ele tenta se manter afastado de Luce, mas tambÃ©m nÃ£o consegue. E a verdade promete separÃ¡-los como tantas outras vezes â€” com a morte de Luce. Amantes destinados a se encontrar e se perder vida apÃ³s vida, sÃ©culo apÃ³s sÃ©culo. Excitante, sombrio e romÃ¢ntico Fallen Ã©, ao mesmo tempo, um thriller vigoroso e uma inesquecÃ­vel histÃ³ria de amor.', 345, 67, 'ae28255492e7ee90ca40b3274934d027..jpg', 'Disponivel'),
(17, 1, 2, 'Infinito', 'Caninos alongados vÃªm dominando o mercado editorial nos Ãºltimos anos. Mas segundo especialistas â€” entre eles o conceituado jornal britÃ¢nico The Observer â€”, asas e plumas prometem acabar com esse reinado. Anjos caÃ­dos sÃ£o a nova onda e comeÃ§am a tomar o lugar dos sugadores de sangue nas prateleiras e nas listas. Assim como seus pÃ¡lidos primos, esses seres celestiais sÃ£o visitantes sobrenaturais, donos de uma carga de adrenalina e sexualidade latente que promete arrebatar os leitores mais jovens. Fallen comprova a forÃ§a da nova tendÃªncia. Com uma trama que gira em torno do amor entre um anjo e uma adolescente, o livro de Lauren Kate foi lanÃ§ado no inÃ­cio de dezembro de 2009 e chegou Ã  lista do NY Times jÃ¡ no fim do mesmo mÃªs. Desde entÃ£o, mantÃ©m presenÃ§a constante na prestigiada tabela. E, a reboque, teve os direitos para o cinema comprados. A expectativa para o longa Ã© tanta, que vÃ¡rios fÃ£s da histÃ³ria postaram suas prÃ³prias versÃµes do trailer â€” e do elenco ideal â€” no Youtube. Lauren aposta no amor impossÃ­vel entre os protagonistas para tecer o inÃ­cio de uma saga com todos os ingredientes de um cult do gÃªnero. Em Fallen, acompanhamos a adolescente Luce, mandada para um reformatÃ³rio â€” apropriadamente batizado de Sword & Cross â€” apÃ³s a morte do namorado em um incÃªndio misterioso. Ela suspeita que estranhas sombras negras, que a atormentam desde a infÃ¢ncia, sÃ£o as verdadeiras responsÃ¡veis. Mas quem acreditaria nela? Na escola, ela encontra o etereamente belo Daniel Grigori, que desperta uma estranha sensaÃ§Ã£o de reconhecimento: Ãºnico ponto luminoso num lugar onde celulares sÃ£o proibidos e hÃ¡ cÃ¢meras de vigilÃ¢ncia por todos os cantos. Mas tanta luz hipnotiza a menina, atraÃ­da pelo rapaz como uma mariposa pela chama. Ele tenta se manter afastado de Luce, mas tambÃ©m nÃ£o consegue. E a verdade promete separÃ¡-los como tantas outras vezes â€” com a morte de Luce. Amantes destinados a se encontrar e se perder vida apÃ³s vida, sÃ©culo apÃ³s sÃ©culo. Excitante, sombrio e romÃ¢ntico Fallen Ã©, ao mesmo tempo, um thriller vigoroso e uma inesquecÃ­vel histÃ³ria de amor.', 345, 78, '1fde7b4e627cf810899293dcb5713dd1..jpg', 'Disponivel'),
(18, 2, 2, 'O exorcista', 'A jovem estudante Emily Rose comeÃ§a a alucinar e ter surtos cada vez mais frequentes, que causam perda de memÃ³ria. CatÃ³lica praticante, ela aceita ser submetida a uma sessÃ£o de exorcismo. Quem a realiza Ã© o sacerdote de sua parÃ³quia, o padre Richard Moore. PorÃ©m, Emily morre durante o exorcismo, o que faz com que o padre seja acusado de assassinato. A advogada Erin Bruner aceita pegar a defesa do padre e argumenta que a condiÃ§Ã£o de Emily nÃ£o pode ser explicada somente pela ciÃªncia.', 678, 100, '0beee4729ec16b499a95a0446b594b3b..png', 'Disponivel'),
(20, 3, 6, 'Rebel Princess Guide - She-ra', 'Magia e rebeldia se misturam quando a meio bruxa e meio humana Sabrina Spellman fica dividida entre a vida de adolescente e o legado de sua família, a Igreja da Noite.', 324, 63, 'df9d60a2ac677dc6d1109c62a08e13fc..jpg', 'Indisponivel'),
(21, 6, 4, 'Origem da ganância', 'Premissa. A série segue Adora, uma órfã criada por Hordak, o tirano que governa o planeta Etheria através de sua horda malvada. Um dia, depois de se perder na floresta, Adora encontra uma espada mágica que a transforma na Princesa do Poder, She-Ra.', 456, 36, '58eda8030ed45f0d825f07ab75728ef3..jpg', 'Disponivel'),
(22, 3, 6, 'Raizes do mal - Stranger Things', 'Premissa. A série segue Adora, uma órfã criada por Hordak, o tirano que governa o planeta Etheria através de sua horda malvada. Um dia, depois de se perder na floresta, Adora encontra uma espada mágica que a transforma na Princesa do Poder, She-Ra.', 245, 56, 'd9d3248a26d3d28dade83172e27df99a..jpg', 'Disponivel'),
(23, 0, 0, '', NULL, 0, 0, 'c731bdaa150640d76c59becee824c011..jpg', ''),
(24, 0, 0, '', NULL, 0, 0, 'd8da3ac71c5b51341762abecd997deab..png', ''),
(25, 0, 0, '', NULL, 0, 0, '0b0e5ce28b25dd8f70e31561da5e5750..png', '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuario`
--

CREATE TABLE `usuario` (
  `codigo_usuario` int(11) NOT NULL,
  `estado` char(2) DEFAULT NULL,
  `cidade` varchar(45) DEFAULT NULL,
  `usuario_nome` varchar(45) NOT NULL,
  `email` varchar(40) DEFAULT NULL,
  `senha` varchar(250) DEFAULT NULL,
  `tipo` varchar(15) DEFAULT NULL,
  `telefone` char(20) DEFAULT NULL,
  `rua` varchar(45) DEFAULT NULL,
  `numero` int(11) DEFAULT NULL,
  `bairro` varchar(45) DEFAULT NULL,
  `cep` varchar(15) DEFAULT NULL,
  `foto_user` text,
  `pedido` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Extraindo dados da tabela `usuario`
--

INSERT INTO `usuario` (`codigo_usuario`, `estado`, `cidade`, `usuario_nome`, `email`, `senha`, `tipo`, `telefone`, `rua`, `numero`, `bairro`, `cep`, `foto_user`, `pedido`) VALUES
(11, 'SP', 'CaiuÃ¡', 'Elena', 'elena@gmail.com', '$$2y$10$/cdDIvq9TYaGe.uDhT9ujuoxP3cp9Nn/WTOd.CtfACw2aR6RMn37y', 'usuario', '(98) 7978-8978', 'Rua do Passeio', 167, 'Centro Passeio Corporate', '19450-000', '84a00a86aa5c47a1ccb21d7caf56a584..jpg', 'criado'),
(15, 'SP', 'Presidente Epitácio', 'Pedro ', 'pedro.gustavo@aluno.ifsp.edu.br', '$2y$10$dH2YfA4E9CWkDiWZ4uxrYObBqYzy84yD/kiaBuHRuNj5.yAdoMO6i', 'administrador', '(66) 6666-768', 'Marquês de São Vicente', 345, 'vila palmira', '19470-000', 'd62db217561cc6c179975c43181b0941..jpg', 'criado'),
(16, 'SP', 'Presidente Epitácio', 'Teresa Chavez', 'teresa@aluno.ifsp.edu.br', '$2y$10$6D6YgKGhcSogmLQNOOL4tuwOhCMQ1Vop/ITOUoBtorxpWLEWeXsQi', 'usuario', '(98) 7978-8978', 'Marquês de São Vicente', 5, '6', '19470-000', 'e4f1098856cdc2bb951c35d009cb030d..jpg', 'criado');

-- --------------------------------------------------------

--
-- Estrutura da tabela `venda`
--

CREATE TABLE `venda` (
  `codigo_venda` int(11) NOT NULL,
  `codigo_usuario_codigo` int(11) NOT NULL,
  `data` date DEFAULT NULL,
  `situacao` varchar(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `venda`
--

INSERT INTO `venda` (`codigo_venda`, `codigo_usuario_codigo`, `data`, `situacao`) VALUES
(1, 16, '2022-12-05', 'solicitada'),
(2, 11, '2022-12-29', 'solicitada');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `autor`
--
ALTER TABLE `autor`
  ADD PRIMARY KEY (`codigo_autor`);

--
-- Índices para tabela `autor_titulo`
--
ALTER TABLE `autor_titulo`
  ADD KEY `codigo_autor_codigo` (`codigo_autor_codigo`),
  ADD KEY `codigo_titulo_codigo` (`codigo_titulo_codigo`);

--
-- Índices para tabela `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`codigo_categoria`);

--
-- Índices para tabela `comentario`
--
ALTER TABLE `comentario`
  ADD PRIMARY KEY (`codigo_comentario`),
  ADD KEY `codigo_titulo_codigo` (`codigo_titulo_codigo`),
  ADD KEY `codigo_usuario_codigo` (`codigo_usuario_codigo`);

--
-- Índices para tabela `compra`
--
ALTER TABLE `compra`
  ADD PRIMARY KEY (`codigo_compra`),
  ADD KEY `codigo_usuario_codigo` (`codigo_usuario_codigo`),
  ADD KEY `codigo_fornecedor_codigo` (`codigo_fornecedor_codigo`);

--
-- Índices para tabela `editora`
--
ALTER TABLE `editora`
  ADD PRIMARY KEY (`codigo_editora`);

--
-- Índices para tabela `favoritado`
--
ALTER TABLE `favoritado`
  ADD PRIMARY KEY (`codigo_favoritado`),
  ADD KEY `codigo_titulo_codigo` (`codigo_titulo_codigo`),
  ADD KEY `codigo_usuario_codigo` (`codigo_usuario_codigo`);

--
-- Índices para tabela `fornecedor`
--
ALTER TABLE `fornecedor`
  ADD PRIMARY KEY (`codigo_fornecedor`);

--
-- Índices para tabela `itemcompra`
--
ALTER TABLE `itemcompra`
  ADD PRIMARY KEY (`codigo_item_compra`),
  ADD KEY `codigo_titulo_codigo` (`codigo_titulo_codigo`),
  ADD KEY `codigo_compra_codigo` (`codigo_compra_codigo`);

--
-- Índices para tabela `itemvenda`
--
ALTER TABLE `itemvenda`
  ADD KEY `codigo_titulo_codigo` (`codigo_titulo_codigo`),
  ADD KEY `codigo_venda_codigo` (`codigo_venda_codigo`);

--
-- Índices para tabela `titulo`
--
ALTER TABLE `titulo`
  ADD PRIMARY KEY (`codigo_titulo`),
  ADD KEY `categoria_codigo` (`categoria_codigo`),
  ADD KEY `editora_codigo` (`editora_codigo`);

--
-- Índices para tabela `usuario`
--
ALTER TABLE `usuario`
  ADD PRIMARY KEY (`codigo_usuario`);

--
-- Índices para tabela `venda`
--
ALTER TABLE `venda`
  ADD PRIMARY KEY (`codigo_venda`),
  ADD KEY `codigo_usuario_codigo` (`codigo_usuario_codigo`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `autor`
--
ALTER TABLE `autor`
  MODIFY `codigo_autor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT de tabela `categoria`
--
ALTER TABLE `categoria`
  MODIFY `codigo_categoria` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `comentario`
--
ALTER TABLE `comentario`
  MODIFY `codigo_comentario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT de tabela `compra`
--
ALTER TABLE `compra`
  MODIFY `codigo_compra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `editora`
--
ALTER TABLE `editora`
  MODIFY `codigo_editora` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT de tabela `favoritado`
--
ALTER TABLE `favoritado`
  MODIFY `codigo_favoritado` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT de tabela `fornecedor`
--
ALTER TABLE `fornecedor`
  MODIFY `codigo_fornecedor` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT de tabela `itemcompra`
--
ALTER TABLE `itemcompra`
  MODIFY `codigo_item_compra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `titulo`
--
ALTER TABLE `titulo`
  MODIFY `codigo_titulo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT de tabela `usuario`
--
ALTER TABLE `usuario`
  MODIFY `codigo_usuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT de tabela `venda`
--
ALTER TABLE `venda`
  MODIFY `codigo_venda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `comentario`
--
ALTER TABLE `comentario`
  ADD CONSTRAINT `comentario_ibfk_1` FOREIGN KEY (`codigo_titulo_codigo`) REFERENCES `titulo` (`codigo_titulo`),
  ADD CONSTRAINT `comentario_ibfk_2` FOREIGN KEY (`codigo_usuario_codigo`) REFERENCES `usuario` (`codigo_usuario`);

--
-- Limitadores para a tabela `compra`
--
ALTER TABLE `compra`
  ADD CONSTRAINT `compra_ibfk_1` FOREIGN KEY (`codigo_usuario_codigo`) REFERENCES `usuario` (`codigo_usuario`),
  ADD CONSTRAINT `compra_ibfk_2` FOREIGN KEY (`codigo_fornecedor_codigo`) REFERENCES `fornecedor` (`codigo_fornecedor`);

--
-- Limitadores para a tabela `favoritado`
--
ALTER TABLE `favoritado`
  ADD CONSTRAINT `favoritado_ibfk_1` FOREIGN KEY (`codigo_titulo_codigo`) REFERENCES `titulo` (`codigo_titulo`),
  ADD CONSTRAINT `favoritado_ibfk_2` FOREIGN KEY (`codigo_usuario_codigo`) REFERENCES `usuario` (`codigo_usuario`);

--
-- Limitadores para a tabela `itemcompra`
--
ALTER TABLE `itemcompra`
  ADD CONSTRAINT `itemcompra_ibfk_1` FOREIGN KEY (`codigo_titulo_codigo`) REFERENCES `titulo` (`codigo_titulo`),
  ADD CONSTRAINT `itemcompra_ibfk_2` FOREIGN KEY (`codigo_compra_codigo`) REFERENCES `compra` (`codigo_compra`);

--
-- Limitadores para a tabela `itemvenda`
--
ALTER TABLE `itemvenda`
  ADD CONSTRAINT `itemvenda_ibfk_1` FOREIGN KEY (`codigo_titulo_codigo`) REFERENCES `titulo` (`codigo_titulo`),
  ADD CONSTRAINT `itemvenda_ibfk_2` FOREIGN KEY (`codigo_venda_codigo`) REFERENCES `venda` (`codigo_venda`);

--
-- Limitadores para a tabela `venda`
--
ALTER TABLE `venda`
  ADD CONSTRAINT `venda_ibfk_1` FOREIGN KEY (`codigo_usuario_codigo`) REFERENCES `usuario` (`codigo_usuario`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
