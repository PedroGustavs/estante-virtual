<script src="js/script.js"></script>
<section class="featured" id="featured">


            <h1 class="heading">
                <span>Novidades que voce precisa conheçer</span>
            </h1>
        


            <div class="swiper featured-slider">

                <div class="swiper-wrapper">
                        <?php

                            $query = "SELECT t.*
                            FROM titulo t, categoria c, autor a, autor_titulo a_t, editora e
                            WHERE t.editora_codigo = e.codigo_editora
                            AND t.categoria_codigo = c.codigo_categoria
                            AND a.codigo_autor = a_t.codigo_autor_codigo
                            AND t.codigo_titulo = a_t.codigo_titulo_codigo
                            ORDER BY t.codigo_titulo";
                            $row = mysqli_query($conn, $query);
                            $num = mysqli_num_rows($row);

                          

                            while($dados = mysqli_fetch_assoc($row)){
                        ?>
                    <div class="swiper-slide box">
                        <div class="icons">                           
                            <?php
                                echo"<a href='carrinho_compra.php?id=".$dados['codigo_titulo']."' class='fas fa-shopping-cart'></a>";
                                $titulo = $dados['codigo_titulo'];
                                echo"<a href='favoritar.php?id=$titulo' id='heart' name='heart'>
                                    <i class='fa-solid fa-heart'></i>  
                                </a>";
                                echo"<a href='livro.php?id=".$dados['codigo_titulo']."' class='fas fa-eye'></a>";
                            ?>
                        </div>
                        
                        <div class="image">
                            <img src="imageTitle/<?php echo $dados['foto'];?>" alt="Imagem">
                        </div>

                        <div class="content">
                            <h3><?php echo $dados['titulo_nome'] ?></h3>
                            <div class="price">
                                <h1>R$<?php echo number_format($dados['valor'], 2, ',', '.')?></h1>
                            </div>                            
                        </div>
                    </div>
                    <?php
                            }
                        
                    ?>
           
                    
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </section>
        <script src="js/script.js"></script>