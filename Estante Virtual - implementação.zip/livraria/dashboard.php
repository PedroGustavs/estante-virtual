<?php
  session_start();
  include_once('sessao.php');//verifica se tem sessão e se está tudo ok!
  $exibirTipodeAcesso = $_SESSION['tipo_acesso'];//recebe o tipo de acesso
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>
        <div class="container">

            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">

                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>

                    </span>
                </div>
                <div class="insights">

                    <?php 
                    if ($exibirTipodeAcesso == "administrador") {
                ?>

                    <div class="sales">
                        <a href="gerenciar_venda.php">
                           <span class="material-symbols-sharp">
                                payments
                            </span> 

                            <h3 class="h3">Gerenciar Vendas</h3>
                        </a>

                    </div>

                    <div class="sales">
                        <a href="gerenciar_compra.php">
                            <span class="material-symbols-sharp">
                                shopping_bag
                            </span>

                            <h3 class="h3">Gerenciar Compras</h3>
                        </a>

                    </div>

                    <div class="sales">
                        <a href="listar_titulo.php">
                            <span class="material-icons-sharp">
                                auto_stories
                            </span>
                            <h3 class="h3">Título</h3>
                        </a>

                    </div>

                    <div class="sales">
                        <a href="listar_editora.php">
                            <span class="material-icons-sharp">
                                store
                            </span>
                            <h3 class="h3">Editora</h3>
                        </a>
                    </div>

                    <div class="sales">
                        <a href="listar_categoria.php">
                            <span class="material-icons-sharp">
                                library_books
                            </span>
                            <h3 class="h3">Categoria</h3>
                        </a>
                    </div>
                    <div class="sales">
                        <a href="listar_fornecedor.php">
                            <span class="material-icons-sharp">
                                person
                            </span>
                            <h3 class="h3">Fornecedor</h3>
                        </a>
                    </div>

                    <div class="sales">
                        <a href="listar_leitor.php">
                            <span class="material-icons-sharp">
                                person
                            </span>
                            <h3 class="h3">Leitor</h3>
                        </a>
                    </div>

                    <div class="sales">
                        <a href="listar_autor.php">
                            <span class="material-icons-sharp">
                                person
                            </span>
                            <h3 class="h3">Autor</h3>
                        </a>
                    </div>                    
                <?php
                }  else {
                ?>

                    <div class="sales">
                        <a href="gerenciar_venda.php">
                            <span class="material-symbols-sharp">
                                shopping_bag
                            </span>

                            <h3 class="h3">Minhas Compras</h3>
                            <?php //filtrar por status, pagamento pendente, preparando,a caminho, finalizado, avaliar ?>
                        </a>

                    </div>

                    <div class="sales">
                        <a href="listar_favoritados.php">

                            <span class="material-symbols-sharp">
                                favorite
                            </span>

                            <?php //filtrar por preço, status(disponivel ou indisponivel), categoria, autor, editora?>

                            <h3 class="h3">Livros Favoritados</h3>
                        </a>
                    </div>

                    <div class="sales">
                        <a href="#">

                            <span class="material-symbols-sharp">
                                comment
                            </span>

                            <h3 class="h3">Meus Comentários</h3>
                        </a>
                    </div>

                    <div class="sales">
                        <a href="#">
                            <span class="material-symbols-sharp">
                                shopping_cart
                            </span>
                            <h3 class="h3">Carrinho de Compras</h3>
                        </a>
                    </div>

                    <div class="sales">
                        <a href="configuracao.php">
                            <span class="material-symbols-sharp">
                                settings
                            </span>
                            <h3 class="h3">Configurações</h3>
                        </a>
                    </div>


                    <?php
                    }
                ?>

                </div>
            </main>

        <?php
            if($exibirTipodeAcesso == "administrador"){
                include_once('right_user.php');
            }  
            
            else{
                ?>

                <div class="user-photo">
                    <img
                                        src="imageTitle/<?php echo $_SESSION['foto'];?>"
                                        alt="Imagem"
                                        width="80px"
                                        heigth="90px">
                <h2><?php echo $_SESSION['nome']?></h2> 
            </div>
            <?php
            }
        ?>

        </div>

    </body>

</html>