<header class="header">

    <div class="header-1">

        <a href="index.php" class="logo"> <i class="fas fa-book"></i> Estante Virtual </a>

        <form action="pesquise.php" class="search-form" method="get">
            <select class="select-search" name="select-search" id="select-search">
                <option value="nome" selected>Nome</option>
                <option value="categoria">Categoria</option>
                <option value="editora">Editora</option>
                <option value="autor">Autor</option>
                <option value="assunto">Assunto</option>
                <option value="preco">Preço maximo</option>
                <option value="preco1">Preço minimo</option>
            </select>
            <input type="search" name="search-box" placeholder="Pesquise" id="search-box">
            
            <button type="submit" name="button-search" id="button-search">
                <i class="fas fa-search"></i>
            </button>          
        </form>

        <div class="icons">
            <div id="search-btn" class="fas fa-search"></div>

            <?php
                session_start();
                echo "<div id='login-btn' class='fas fa-user'></div>";
    
                if(isset($_SESSION['tipo_acesso'])){
                    $tipo = $_SESSION['tipo_acesso'];
                    
            ?>
                   
                        <a href='dashboard.php'>
                            <i class='fa-solid fa-gear'></i>
                        </a>
                 

                    <a href="sair.php">
                    <i class="fa-solid fa-right-from-bracket"></i>
                    </a>       
            <?php

                    if($tipo == "usuario"){
                        echo "<a href='listar_favoritados.php' class='fas fa-heart'></a>
                        <a href='carrinho_compra.php' class='fas fa-shopping-cart'></a>";
                    }    
                }
            ?>
        </div>

      
    </div>


    <div class="header-2">
        <nav class="navbar">
            <a href="index.php#home" class="r-link text-underlined">Home</a>
            <a href="index.php#categorias" class="r-link text-underlined">Categorias</a>
            <a href="index.php#featured" class="r-link text-underlined">Novidades</a>
            <a href="index.php#featured1" class="r-link text-underlined">Populares</a>
        </nav>
    </div>
    
    <nav class="bottom-navbar">
        <a href="#home"></a>
        <a href="#categorias"></a>
        <a href="#novidades"></a>
        <a href="#populares"></a>
    </nav>
</header>