<?php
  session_start();
  include_once('sessao.php');
  include_once('conexao.php');

  $exibirTipodeAcesso = $_SESSION['tipo_acesso'];
  if($exibirTipodeAcesso != "usuario"){
    header("location:dashboard.php");
  }
?>

<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Dashboard</title>
        <link rel="stylesheet" href="css/dashboard.css">
        <link rel="stylesheet" href="css/aside.css">
        <link rel="stylesheet" href="https://unpkg.com/swiper@7/swiper-bundle.min.css"/>
        <link
            rel="stylesheet"
            href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/css2?family=Material+Symbols+Sharp:opsz,wght,FILL,GRAD@48,400,0,0"/>
        <script src="https://kit.fontawesome.com/be8696c5b7.js" crossorigin="anonymous"></script>
        <link
            rel="stylesheet"
            href="https://fonts.googleapis.com/icon?family=Material+Icons+Sharp">
    </head>

    <body>
        <div class="container">

            <?php include_once('menu_user.php')?>

            <main>
                <div class="link">

                    <span>
                        <a href="dashboard.php">
                            Dashboard
                        </a>

                    </span>
                </div>

                <div class="recent-users">
                    <table>
                        <h2 class="crud">Livros Comentados</h2>
                        <thead>
                            <tr>
                                <th>Imagem</th>
                                <th>Nome</th>
                                <th>Status</th>
                                <th>Quantidade que comentou</th>
                                <th>Operações</th>                                  
                            </tr>
                        </thead>

                        <tbody>
                            <?php
                                $cod = $_SESSION['idusuario'];

                                $verificadora = false;

                                $query = "SELECT *, COUNT(*) AS qntdd
                                FROM comentario f, titulo t, usuario
                                WHERE codigo_usuario_codigo = $cod
                                AND codigo_usuario = $cod
                                AND codigo_titulo_codigo = codigo_titulo
                                GROUP BY codigo_titulo                             
                                ORDER BY codigo_comentario";
                                $row = mysqli_query($conn, $query);
                                while($dados = mysqli_fetch_assoc($row)){
                                    
                                    
                            ?>

                            <tr>
                                <td>
                                    <img
                                        src="imageTitle/<?php echo $dados['foto'];?>"
                                        alt="Imagem"
                                        width="70px"
                                        heigth="70px">
                                </td>

                                <td><?php echo $dados['titulo_nome'];?></td>
                                <td><?php echo $dados['status'];?></td>
                                <td><?php echo $dados['qntdd'];?></td>
                                <td>
                                    <div class="td">
                                        <?php 
                                        $titulo = $dados['codigo_titulo'];
                                        $coment = $dados['codigo_comentario'];
                                        $opcao = 1;
                                            echo"<a href='carrinho_compra.php?id=".$dados['codigo_titulo']."'><i class='fas fa-shopping-cart fa-2x'></i></a>";
                                            echo"<a href='livro.php?id=".$dados['codigo_titulo']."'><i class='fa-solid fa-eye fa-2x'></i></a>";
                                        ?>
                                    </div>
                                </td>
                            </tr>
                             <?php
                                }
                            ?>
                        </tbody>
                    </table>
                   
                </div>
            </main>



                <div class="user-photo">
                    <img
                                        src="imageTitle/<?php echo $_SESSION['foto'];?>"
                                        alt="Imagem"
                                        width="80px"
                                        heigth="90px">
                <h2><?php echo $_SESSION['nome']?></h2> 
            </div>

        </div>

    </body>
    <script src="js/funcoes.js"></script>
</html>