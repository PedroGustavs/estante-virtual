<?php
  $exibirTipodeAcesso = $_SESSION['tipo_acesso'];//recebe o tipo de acesso
?>

<aside>
    <div class="top">
        <div class="logo">
            <a href="dashboard.php">
                <span class="material-icons-sharp logo-icon">
                    auto_stories
                </span>
                <h2>Estante<span class="danger">Virtual</span></h2>
            </a>
        </div>
        <div class="close" id="close-btn">
            <span class="material-icons-sharp">
                close
            </span>
        </div>

    </div>
    <div class="sidebar">
        <a href="dashboard.php">
            <span class="material-icons-sharp">
                dashboard
            </span>
            <h3>Dashboard</h3>
        </a>

        <?php
            if($exibirTipodeAcesso == "administrador"){
        ?>

        <a href="listar_titulo.php">
            <span class="material-icons-sharp">
                auto_stories
            </span>

            <h3>Titulos</h3>
            <span class="message-count">
                <?php
                    include_once('conexao.php');       
                    $query = "SELECT t.*, c.*, e.*
                    FROM titulo t, categoria c, editora e
                    WHERE t.editora_codigo = e.codigo_editora
                    AND t.categoria_codigo = c.codigo_categoria
                    ORDER BY t.codigo_titulo";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </span>
        </a>

        <a href="listar_categoria.php">
        <span class="material-icons-sharp">
                                library_books
                            </span>

            <h3>Categorias</h3>
            <span class="message-count">
                <?php
                    include_once('conexao.php');       
                    $query = "SELECT *
                    FROM categoria c
                    ORDER BY codigo_categoria";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </span>
        </a>

        <a href="listar_editora.php">
        <span class="material-icons-sharp">
                                store
                            </span>

            <h3>Editora</h3>
            <span class="message-count">
                <?php
                    include_once('conexao.php');       
                    $query = "SELECT *
                    FROM editora
                    ORDER BY codigo_editora";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </span>
        </a>

        <a href="listar_leitor.php">
        <span class="material-icons-sharp">
                                person
                            </span>

            <h3>Leitores</h3>
            <span class="message-count">
                <?php
                $tipo = "usuario";
                    include_once('conexao.php');       
                    $query = "SELECT *
                    FROM usuario
                    WHERE tipo = '$tipo'
                    ORDER BY codigo_usuario";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </span>
        </a>

        <a href="listar_autor.php">
        <span class="material-icons-sharp">
                                person
                            </span>

            <h3>Autores</h3>
            <span class="message-count">
                <?php
                    include_once('conexao.php');       
                    $query = "SELECT *
                    FROM autor
                    ORDER BY codigo_autor";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </span>
        </a>

        <a href="listar_fornecedor.php">
        <span class="material-icons-sharp">
                                person
                            </span>

            <h3>Fornecedores</h3>
            <span class="message-count">
                <?php
                    include_once('conexao.php');       
                    $query = "SELECT *
                    FROM fornecedor
                    ORDER BY codigo_fornecedor";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </span>
        </a>

        <a href="gerenciar_compra.php">
            <span class="material-symbols-sharp">
                shopping_bag
            </span>

            <h3>Compras</h3>

            <span class="message-count">
                <?php
                    include_once('conexao.php');
                    $cod = $_SESSION['idusuario'];
                    $tipo = $_SESSION['tipo_acesso'];
                    $query = "SELECT codigo_compra
                    FROM itemcompra, compra, titulo, usuario, fornecedor
                    WHERE codigo_usuario_codigo = $cod
                    AND codigo_usuario = $cod
                    AND codigo_titulo_codigo = codigo_titulo
                    AND codigo_compra_codigo = codigo_compra
                    AND codigo_fornecedor_codigo = codigo_fornecedor
                    ORDER BY codigo_compra";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </span>
        </a>


        <a href="gerenciar_venda.php">
            <span class="material-symbols-sharp">
                payments
            </span>
            <h3>Vendas</h3>
            <span class="message-count">
                <?php
                    include_once('conexao.php');
                    $cod = $_SESSION['idusuario'];
                    $query = "SELECT codigo_venda
                    FROM itemvenda, venda, titulo, usuario
                    WHERE codigo_usuario_codigo = codigo_usuario
                    AND codigo_titulo_codigo = codigo_titulo
                    AND codigo_venda_codigo = codigo_venda
                    ORDER BY codigo_venda";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </span>
        </a>

        <a href="listar_solicitacoes.php">
            <span class="material-icons-sharp">
                mail_outline
            </span>
            <h3>Mensagens</h3>
            <span class="message-count">

            <?php
                    include_once('conexao.php');       
                    $query = "SELECT *
                    FROM usuario
                    WHERE tipo = 'usuario'
                    AND pedido = 'solicitado'
                    ORDER BY codigo_usuario";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </span>
        </a>

    <?php
            } else {
        ?>

        <a href="gerenciar_venda.php">

            <span class="material-symbols-sharp">
                shopping_bag
            </span>

            <h3>Minhas Compras</h3>
            <span class="message-count">
                <?php
                    include_once('conexao.php');
                    $cod = $_SESSION['idusuario'];
                    $query = "SELECT codigo_venda
                    FROM itemvenda, venda, titulo, usuario
                    WHERE codigo_usuario_codigo = codigo_usuario
                    AND codigo_usuario = $cod
                    AND codigo_titulo_codigo = codigo_titulo
                    AND codigo_venda_codigo = codigo_venda
                    ORDER BY codigo_venda";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
            </span>
        </a>

        <a href="listar_favoritados.php">
            <span class="material-symbols-sharp">
                favorite
            </span>
            <h3>Livros Favoritados</h3>
            <span class="message-count">
                <?php
                    include_once('conexao.php');
                    $cod = $_SESSION['idusuario'];
                    $query = "SELECT *
                    FROM favoritado, titulo
                    WHERE codigo_usuario_codigo = $cod
                    AND codigo_titulo_codigo = codigo_titulo ORDER BY codigo_titulo";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
                </span>
        </a>

        <a href="listar_comentarios.php">
            <span class="material-symbols-sharp">
                comment
            </span>
            <h3>Meus Comentários</h3>

            <span class="message-count">
                <?php
                    include_once('conexao.php');
                    $cod = $_SESSION['idusuario'];
                    $query = "SELECT *
                    FROM comentario, titulo
                    WHERE codigo_usuario_codigo = $cod
                    AND codigo_titulo_codigo = codigo_titulo ORDER BY codigo_comentario";
                    $result = mysqli_query($conn, $query);
                    $row = mysqli_num_rows($result);
                    echo $row;
                ?>
                </span>
        </a>

        <?php
            }
        ?>

        <a href="configuracao.php">
            <span class="material-icons-sharp">
                settings
            </span>
            <h3>Configurações</h3>
        </a>

        <a href="index.php">
            <span class="material-symbols-sharp">
                visibility
            </span>
            <h3>Visualizar Livraria 
                
            </h3>
        </a>

        <a href="sair.php">
            <span class="material-icons-sharp">
                logout
            </span>
            <h3>Sair</h3>
        </a>

    </div>
</aside>